namespace efront.Runtime.Connector.Model;

public enum AuthLoginResultCode
{
	Ok,
	UserOrPasswordIncorrect,
	UserLocked,
	PasswordExpired,
	SecondPasswordRequired,
	MissingClientVersion,
	InvalidClientVersion,
	Failure,
	Unauthorized
}
