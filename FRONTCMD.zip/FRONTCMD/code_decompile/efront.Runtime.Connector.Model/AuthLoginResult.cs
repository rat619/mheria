using System.Runtime.Serialization;

namespace efront.Runtime.Connector.Model;

[DataContract]
public class AuthLoginResult
{
	[DataMember]
	public AuthLoginResultCode ResultCode { get; set; }

	public string ResultCodeLabel => ResultCode.ToString();

	[DataMember]
	public string ResultMessage { get; set; }

	public string AntiCsrfToken { get; set; }

	public AuthLoginResult(AuthLoginResultCode resultCode, string resultMessage)
	{
		ResultCode = resultCode;
		ResultMessage = resultMessage;
	}

	public static AuthLoginResult WithCode(AuthLoginResultCode loginErrorCode)
	{
		return new AuthLoginResult(loginErrorCode, string.Empty);
	}
}
