namespace CommonClientConnector.Adfs;

public class AdfsWifParameters
{
	public string Wa { get; set; }

	public string WResult { get; set; }

	public string WCtx { get; set; }
}
