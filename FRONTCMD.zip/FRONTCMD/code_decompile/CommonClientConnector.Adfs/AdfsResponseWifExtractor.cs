using System;
using System.Linq;
using System.Xml.Linq;

namespace CommonClientConnector.Adfs;

public class AdfsResponseWifExtractor : IAdfsResponseWifExtractor
{
	public AdfsWifParameters ExtractWifParametersFromResponse(string adfsResponseText)
	{
		AdfsWifParameters adfsWifParameters = new AdfsWifParameters();
		XDocument val = XDocument.Parse(adfsResponseText);
		XElement val2 = (from n in ((XContainer)val).Descendants(XName.op_Implicit("input"))
			where (string)n.Attribute(XName.op_Implicit("name")) == "wa"
			select n).FirstOrDefault();
		if (val2 == null || !val2.HasAttributes || string.IsNullOrEmpty((string)val2.Attribute(XName.op_Implicit("value"))))
		{
			throw new Exception("Invalid ADFS response - The parameter WA could not be found");
		}
		adfsWifParameters.Wa = val2.Attribute(XName.op_Implicit("value")).Value;
		XElement val3 = (from n in ((XContainer)val).Descendants(XName.op_Implicit("input"))
			where (string)n.Attribute(XName.op_Implicit("name")) == "wresult"
			select n).FirstOrDefault();
		if (val3 == null || !val3.HasAttributes || string.IsNullOrEmpty((string)val3.Attribute(XName.op_Implicit("value"))))
		{
			throw new Exception("Invalid ADFS response - The parameter WRESULT could not be found");
		}
		adfsWifParameters.WResult = val3.Attribute(XName.op_Implicit("value")).Value;
		XElement val4 = (from n in ((XContainer)val).Descendants(XName.op_Implicit("input"))
			where (string)n.Attribute(XName.op_Implicit("name")) == "wctx"
			select n).FirstOrDefault();
		if (val4 == null || !val4.HasAttributes || string.IsNullOrEmpty((string)val4.Attribute(XName.op_Implicit("value"))))
		{
			throw new Exception("Invalid ADFS response - The parameter WCTX could not be found");
		}
		adfsWifParameters.WCtx = val4.Attribute(XName.op_Implicit("value")).Value;
		return adfsWifParameters;
	}
}
