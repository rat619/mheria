namespace CommonClientConnector.Adfs;

public interface IAdfsResponseWifExtractor
{
	AdfsWifParameters ExtractWifParametersFromResponse(string adfsResponseText);
}
