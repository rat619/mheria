using CommandLine;

namespace FrontCmd;

public class EncryptArguments : BaseArguments
{
	[DefaultArgument(ArgumentType.Required, HelpText = "Text to encrypt.")]
	public string text;
}
