using CommandLine;

namespace FrontCmd;

public class ExecFolderArguments : BaseArguments
{
	[Argument(ArgumentType.Required, HelpText = "Url of the server on which to execute the folder.")]
	public string server = "";

	[Argument(ArgumentType.AtMostOnce, ShortName = "uid", HelpText = "Userid of the user account to execute the folder under.")]
	public string userid = "";

	[Argument(ArgumentType.AtMostOnce, ShortName = "pwd", HelpText = "Password of the user. (Can be encrypted.)")]
	public string password = "";

	[Argument(ArgumentType.AtMostOnce, ShortName = "oidcert", HelpText = "The thumbprint of the certifcate that will be used for OpenId authentication")]
	public string openIdCertThumb = "";

	[Argument(ArgumentType.AtMostOnce, ShortName = "oidsecret", HelpText = "The client secret that will be used for OpenId authentication")]
	public string openIdSecret = "";

	[Argument(ArgumentType.AtMostOnce, ShortName = "pwdcard", HelpText = "Password card of the user. If 2nd auth is enabled on server.")]
	public string passwordCard = "";

	[Argument(ArgumentType.Required, ShortName = "fld", HelpText = "Name of the folder on which to call the method.")]
	public string folder = "";

	[Argument(ArgumentType.Required, HelpText = "Name of the method to call.")]
	public string method = "";

	[Argument(ArgumentType.AtMostOnce, HelpText = "';' list of FrontCube URL server")]
	public string frontCubeUrls = "";

	[Argument(ArgumentType.Multiple, LongName = "params", AllowEmptyValue = true, HelpText = "Value of an input parameter.")]
	public string[] parameters;

	[Argument(ArgumentType.Multiple, LongName = "outputParams", ShortName = "op", AllowEmptyValue = true, HelpText = "Initial value for an output parameter. (Can be empty.)")]
	public string[] outputParameters;

	[Argument(ArgumentType.MultipleUnique, HelpText = "Path name of an input file.")]
	public string[] files;

	[Argument(ArgumentType.MultipleUnique, ShortName = "of", AllowEmptyValue = true, HelpText = "Directory or full pathname for an output file. (Can be empty.)")]
	public string[] outputFiles;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = 32, HelpText = "File transfer buffer size in K.")]
	public int chunkSize;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = false, HelpText = "Overwrite any existing files output files.")]
	public bool overwrite;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = true, HelpText = "Display detailed progress information.")]
	public bool verbose = true;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = false, HelpText = "When executing a report on the server, use FrontReport")]
	public bool useFrontReport;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = true, ShortName = "dl", HelpText = "Download report output files")]
	public bool downloadOutputFiles = true;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = false, ShortName = "f", HelpText = "Force download of output files even if an error occurred during execution")]
	public bool getOutputsEvenOnError;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = false, ShortName = "a", HelpText = "Starts a asynchronous task and returns the task id")]
	public bool isAsync;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = 30000, ShortName = "pf", HelpText = "Asynchronous task polling frequency")]
	public int pollFrequency;

	[Argument(ArgumentType.AtMostOnce, DefaultValue = 120, ShortName = "tm", HelpText = "Remote Execution Timeout (minutes)")]
	public int timeout;
}
