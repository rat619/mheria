using System;

namespace FrontCmd;

public abstract class Command
{
	private bool verbose;

	protected Commands Commands { get; set; }

	protected BaseArguments CommandArguments { get; set; }

	public Command(Commands commands, BaseArguments commandArguments)
	{
		Commands = commands;
		CommandArguments = commandArguments;
		verbose = true;
	}

	protected abstract bool DoRun();

	public bool Run()
	{
		int tickCount = Environment.TickCount;
		bool flag = false;
		try
		{
			flag = DoRun();
			return flag;
		}
		finally
		{
			if (flag)
			{
				Console.WriteLine("\r\n" + Commands.ToString() + " completed successfully");
			}
			if (verbose)
			{
				Console.WriteLine("Total Execution Time: " + Rt.GetDurationString(Environment.TickCount - tickCount));
			}
		}
	}
}
