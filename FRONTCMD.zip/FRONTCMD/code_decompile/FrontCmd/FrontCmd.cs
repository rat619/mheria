using System;
using System.IO;
using System.Reflection;
using CommandLine;

namespace FrontCmd;

internal class FrontCmd
{
	[STAThread]
	private static void Main(string[] args)
	{
		Environment.ExitCode = 0;
		try
		{
			DisplayProgramInformation();
			CommandArguments commandArguments = new CommandArguments();
			if (!ParseCommandLine(GetCommandArg(args), commandArguments, showExitCodes: true))
			{
				return;
			}
			switch (commandArguments.command)
			{
			case Commands.ExecFolder:
			case Commands.ExecReportWithXmlFileParams:
			case Commands.ExecReportWithInLineParams:
			case Commands.Import:
			case Commands.ExecReport:
			case Commands.ExecImport:
			case Commands.WebEdgeImport:
			case Commands.ExecWebEdgeImport:
			case Commands.SetFrontCubeURLs:
			{
				switch (commandArguments.command)
				{
				case Commands.ExecReportWithXmlFileParams:
				{
					string[] array = new string[args.Length + 2];
					args.CopyTo(array, 0);
					array[args.Length] = "/folder:F_AJXREPEXECPROGRAM";
					array[args.Length + 1] = "/method:ExecFrontcmdWithXmlFileParams";
					args = array;
					break;
				}
				case Commands.ExecReportWithInLineParams:
				{
					string[] array = new string[args.Length + 2];
					args.CopyTo(array, 0);
					array[args.Length] = "/folder:F_AJXREPEXECPROGRAM";
					array[args.Length + 1] = "/method:ExecFrontcmdWithInLineParams";
					args = array;
					break;
				}
				case Commands.ExecReport:
				{
					string[] array = new string[args.Length + 2];
					args.CopyTo(array, 0);
					array[args.Length] = "/folder:F_AJXREPEXECPROGRAM";
					array[args.Length + 1] = "/method:EXECREPORTMETHOD";
					args = array;
					break;
				}
				case Commands.Import:
				case Commands.ExecImport:
				{
					string[] array = new string[args.Length + 2];
					args.CopyTo(array, 0);
					array[args.Length] = "/folder:F_SFAIMP1";
					array[args.Length + 1] = "/method:ExecFrontcmd";
					args = array;
					break;
				}
				case Commands.WebEdgeImport:
				case Commands.ExecWebEdgeImport:
				{
					string[] array = new string[args.Length + 2];
					args.CopyTo(array, 0);
					array[args.Length] = "/folder:F_AJXCRMNEWIMPORT";
					array[args.Length + 1] = "/method:ImportExcelFile";
					args = array;
					break;
				}
				case Commands.SetFrontCubeURLs:
				{
					string[] array = new string[args.Length + 2];
					args.CopyTo(array, 0);
					array[args.Length] = "/folder:SetFrontCubeURLs";
					array[args.Length + 1] = "/method:SetFrontCubeURLs";
					args = array;
					break;
				}
				}
				ExecFolderArguments execFolderArguments = new ExecFolderArguments();
				if (ParseCommandLine(GetCommandArgs(args), execFolderArguments))
				{
					if (!CheckAndFixParameters(commandArguments.command, execFolderArguments))
					{
						DisplayUsage(commandArguments.command);
					}
					else
					{
						new ExecFolderCommand(execFolderArguments, commandArguments.command == Commands.ExecImport || commandArguments.command == Commands.Import || execFolderArguments.getOutputsEvenOnError).Run();
					}
				}
				break;
			}
			case Commands.Encrypt:
			{
				EncryptArguments encryptArguments = new EncryptArguments();
				if (ParseCommandLine(GetCommandArgs(args), encryptArguments))
				{
					new EncryptCommand(encryptArguments).Run();
				}
				break;
			}
			case Commands.Export:
				break;
			}
		}
		catch (Exception ex)
		{
			ReportError(ExitCodes.UnhandledException, "An unhandled exception occurred: " + ex.ToString());
		}
	}

	private static bool CheckAndFixParameters(Commands command, ExecFolderArguments efa)
	{
		Commands commands = command;
		if (commands == Commands.ExecReport)
		{
			if (efa.files == null || efa.files.Length == 0)
			{
				efa.method = "ExecFrontcmdWithInLineParams";
				commands = Commands.ExecReportWithInLineParams;
			}
			else
			{
				efa.method = "ExecFrontcmdWithXmlFileParams";
				commands = Commands.ExecReportWithXmlFileParams;
			}
		}
		switch (commands)
		{
		case Commands.ExecReportWithInLineParams:
			if (efa.parameters == null || efa.parameters.Length == 0)
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithInLineParams: missing report path parameter");
				return false;
			}
			if (efa.parameters.Length == 1)
			{
				efa.parameters = new string[2]
				{
					efa.parameters[0],
					""
				};
			}
			else if (efa.parameters.Length > 2)
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithInLineParams: too many input parameters supplied");
				return false;
			}
			if (efa.outputParameters == null || efa.outputParameters.Length == 0)
			{
				efa.outputParameters = new string[1] { "ExecReportResult" };
			}
			else if (efa.outputParameters.Length > 1)
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithInLineParams: too many output parameters supplied");
				return false;
			}
			if (efa.outputFiles == null || efa.outputFiles.Length == 0)
			{
				efa.outputFiles = new string[1] { Environment.CurrentDirectory };
			}
			break;
		case Commands.ExecReportWithXmlFileParams:
			if (efa.parameters == null || efa.parameters.Length == 0 || efa.files == null || efa.files.Length != 1)
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithXmlFileParams: invalid input parameters supplied. Report path (using /params) and xml file path (using /files) parameters required.");
				return false;
			}
			if ((efa.parameters != null && efa.parameters.Length > 1) || (efa.files != null && efa.files.Length > 1))
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithXmlFileParams: too many input or files parameters supplied");
				return false;
			}
			if (efa.files[0] == null || efa.files.Length != 1)
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithXmlFileParams: ExecReportWithXmlFileParams required one '/files' parameter that specifies the XML parameters file.");
				return false;
			}
			if (!File.Exists(efa.files[0]))
			{
				ReportError(ExitCodes.FileNotFound, $"ExecReportWithXmlFileParams: XML input file '{efa.files[0]}' does not exist.");
				return false;
			}
			if (efa.outputParameters == null || efa.outputParameters.Length == 0)
			{
				efa.outputParameters = new string[1] { "ExecReportResult" };
			}
			else if (efa.outputParameters.Length > 1)
			{
				ReportError(ExitCodes.CommandLineError, "ExecReportWithInLineParams: too many output parameters supplied");
				return false;
			}
			if (efa.outputFiles == null || efa.outputFiles.Length == 0)
			{
				efa.outputFiles = new string[1] { Environment.CurrentDirectory };
			}
			break;
		case Commands.Import:
		case Commands.ExecImport:
			if (efa.parameters == null || (efa.parameters.Length != 1 && efa.parameters.Length != 2))
			{
				ReportError(ExitCodes.CommandLineError, "Import: invalid input parameters. Matrix name and input file required");
				return false;
			}
			if (efa.parameters.Length == 1)
			{
				string[] array = new string[efa.parameters.Length + 1];
				efa.parameters.CopyTo(array, 0);
				array[^1] = "";
				efa.parameters = array;
			}
			if (efa.outputParameters == null || efa.outputParameters.Length == 0)
			{
				efa.outputParameters = new string[1] { "ImportOutputLog" };
			}
			else if (efa.outputParameters.Length > 1)
			{
				ReportError(ExitCodes.CommandLineError, "Import: too many output parameters supplied");
				return false;
			}
			if (efa.files == null || efa.files.Length != 1)
			{
				ReportError(ExitCodes.CommandLineError, "Import: input file not specified");
				return false;
			}
			if (!File.Exists(efa.files[0]))
			{
				ReportError(ExitCodes.FileNotFound, "Import: input file does not exist");
				return false;
			}
			break;
		case Commands.WebEdgeImport:
		case Commands.ExecWebEdgeImport:
		{
			string message = "ExecWebEdgeImport: You need to specify one input file. Either using /file in order to upload the input file to the server, or using /params to specify a full path on the server containing the the input data file.";
			if (efa.parameters.Length == 0)
			{
				if (efa.files == null || efa.files.Length == 0)
				{
					ReportError(ExitCodes.CommandLineError, message);
					return false;
				}
				efa.parameters = new string[1] { "" };
			}
			else
			{
				if (efa.parameters.Length > 1)
				{
					ReportError(ExitCodes.CommandLineError, "ExecWebEdgeImport: only one input parameters can be specified - the full path on the server containing the input data file");
					return false;
				}
				if (efa.files != null && efa.files.Length != 0)
				{
					ReportError(ExitCodes.CommandLineError, message);
					return false;
				}
				efa.parameters = new string[2]
				{
					"",
					efa.parameters[0]
				};
			}
			if (efa.outputFiles == null || efa.outputFiles.Length == 0)
			{
				efa.outputFiles = new string[1] { Environment.CurrentDirectory };
			}
			break;
		}
		}
		if (commands == Commands.ExecReportWithInLineParams || commands == Commands.ExecReportWithXmlFileParams)
		{
			string[] array2 = new string[efa.parameters.Length + 1];
			efa.parameters.CopyTo(array2, 0);
			array2[^1] = efa.useFrontReport.ToString();
			efa.parameters = array2;
		}
		return true;
	}

	private static bool ParseCommandLine(string[] args, BaseArguments parsedArgs, bool showExitCodes)
	{
		if (!Parser.ParseArgumentsWithUsage(args, parsedArgs))
		{
			if (showExitCodes)
			{
				Console.WriteLine();
				DisplayExitCodes();
				DisplayDoc();
			}
			Environment.ExitCode = 2;
			return false;
		}
		return true;
	}

	private static bool ParseCommandLine(string[] args, BaseArguments parsedArgs)
	{
		return ParseCommandLine(args, parsedArgs, showExitCodes: false);
	}

	private static void DisplayProgramInformation()
	{
		VersionInformation versionInformation = new VersionInformation();
		Console.WriteLine(versionInformation.Title + " Version " + versionInformation.Version);
		Console.WriteLine(versionInformation.Copyright);
		Console.WriteLine();
	}

	private static string[] GetCommandArg(string[] args)
	{
		if (args.Length != 0)
		{
			return new string[1] { args[0] };
		}
		return new string[0];
	}

	private static string[] GetCommandArgs(string[] args)
	{
		if (args.Length > 1)
		{
			string[] array = new string[args.Length - 1];
			Array.Copy(args, 1, array, 0, array.Length);
			return array;
		}
		return new string[0];
	}

	public static void ReportError(ExitCodes exitCode, string message)
	{
		Console.WriteLine("ERROR: " + message);
		Environment.ExitCode = (int)exitCode;
	}

	private static void DisplayExitCodes()
	{
		Console.WriteLine("ExitCodes:");
		string[] names = Enum.GetNames(typeof(ExitCodes));
		Array values = Enum.GetValues(typeof(ExitCodes));
		int num = 0;
		int i = 0;
		for (int num2 = names.Length; i < num2; i++)
		{
			if (names[i].Length > num)
			{
				num = names[i].Length;
			}
		}
		int j = 0;
		for (int num3 = names.Length; j < num3; j++)
		{
			Console.WriteLine(names[j].PadRight(num) + " " + (int)values.GetValue(j));
		}
	}

	private static void DisplayDoc()
	{
		Console.WriteLine("Documentation:\n");
		using StreamReader streamReader = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("FrontCmd.documentation.txt"));
		Console.WriteLine(streamReader.ReadToEnd());
	}

	private static void DisplayUsage(Commands command)
	{
		switch (command)
		{
		case Commands.ExecReport:
			Console.WriteLine("\r\nUsage: FrontCmd ExecReport /server:<ServerName> [/userid:<UserId>] [/password:<Password>] /params:<ReportPath> [/params:<InlineParameters>] [/files:<InputParametersFile>] [/outputFiles:<OutputPathOrFileName>] [/getOutputsEvenOnError]");
			break;
		case Commands.ExecImport:
			Console.WriteLine("\r\nUsage: FrontCmd ExecImport /server:<ServerName> [/userid:<UserId>] [/password:<Password>] /params:<ImportMatrixName> /files:<InputImportFile> [/outputFiles:<OutputLogFile>] [/getOutputsEvenOnError]");
			break;
		case Commands.ExecFolder:
			Console.WriteLine("\r\nUsage: FrontCmd ExecFolder /server:<ServerName> [/userid:<UserId>] [/password:<Password>] /folder:<FolderName> /method:<MethodName> [/params:<InputParameter1>] [/params:<InputParameter2>]... [/outputParams:\"[<OutputParameter1InitialValue>]\"] [/outputParams:\"[<OutputParameter2InitialValue>]\"] [/getOutputsEvenOnError]\r\nImportant: input and output parameters should be specified in the same order as in the signature of the method");
			break;
		}
	}
}
