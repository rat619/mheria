using System;

namespace FrontCmd;

public class EncryptCommand : Command
{
	private EncryptArguments Arguments => (EncryptArguments)base.CommandArguments;

	public EncryptCommand(EncryptArguments ea)
		: base(Commands.Encrypt, ea)
	{
	}

	protected override bool DoRun()
	{
		Console.WriteLine("Encrypted text: <enc:" + Rt.Encrypt(Arguments.text) + ">");
		return true;
	}
}
