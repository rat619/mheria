using System;
using System.Reflection;

namespace FrontCmd;

public class VersionInformation
{
	private Assembly assembly;

	public Assembly Assembly
	{
		get
		{
			if (assembly == null)
			{
				assembly = Assembly.GetExecutingAssembly();
			}
			return assembly;
		}
	}

	public string Title
	{
		get
		{
			if (GetAttribute(typeof(AssemblyTitleAttribute)) is AssemblyTitleAttribute assemblyTitleAttribute)
			{
				return assemblyTitleAttribute.Title;
			}
			return "";
		}
	}

	public string Copyright
	{
		get
		{
			if (GetAttribute(typeof(AssemblyCopyrightAttribute)) is AssemblyCopyrightAttribute assemblyCopyrightAttribute)
			{
				return assemblyCopyrightAttribute.Copyright;
			}
			return "";
		}
	}

	public string Version => Assembly.GetExecutingAssembly().GetName().Version.ToString();

	public VersionInformation()
		: this(null)
	{
	}

	public VersionInformation(Assembly assembly)
	{
		this.assembly = assembly;
	}

	private Attribute GetAttribute(Type type)
	{
		object[] customAttributes = Assembly.GetCustomAttributes(type, inherit: false);
		if (customAttributes.Length != 0)
		{
			return customAttributes[0] as Attribute;
		}
		return null;
	}
}
