namespace FrontCmd;

public enum Commands
{
	ExecFolder,
	Encrypt,
	ExecReportWithXmlFileParams,
	ExecReportWithInLineParams,
	Export,
	Import,
	ExecReport,
	ExecImport,
	WebEdgeImport,
	ExecWebEdgeImport,
	SetFrontCubeURLs
}
