using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace FrontCmd;

public class TrustAllCertificatePolicy : ICertificatePolicy
{
	public bool CheckValidationResult(ServicePoint sp, X509Certificate cert, WebRequest req, int problem)
	{
		return true;
	}

	public static bool TrustAllCertificateCallback(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors)
	{
		return true;
	}
}
