namespace FrontCmd;

public class BaseArguments
{
}
