using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Services.Protocols;
using System.Xml;
using CommonClientConnector;
using FrontCmd.LoginManager;
using FrontCmd.efront1;
using efront.Runtime.Connector.Model;

namespace FrontCmd;

public class ExecFolderCommand : Command
{
	private WsFrontAdmin fa;

	private string[] loutputParameters;

	private string[] uploadTickets;

	private string[] downloadTickets;

	private string execFolderResult;

	private Exception execFolderException;

	private int updateFrequency;

	private int pollFrequency;

	private volatile bool isExecFolderFinished;

	private bool getOutputsEvenOnError;

	private int[] tryGetStatusRetriesPeriod = new int[3] { 1000, 3000, 10000 };

	private ExecFolderArguments Arguments => (ExecFolderArguments)base.CommandArguments;

	public ExecFolderCommand(ExecFolderArguments efa)
		: this(efa, getOutputsEvenOnError: false)
	{
	}

	public ExecFolderCommand(ExecFolderArguments efa, bool getOutputsEvenOnError)
		: base(Commands.ExecFolder, efa)
	{
		if (Arguments.outputParameters != null && Arguments.outputParameters.Length != 0)
		{
			loutputParameters = new string[Arguments.outputParameters.Length];
			Arguments.outputParameters.CopyTo(loutputParameters, 0);
		}
		else
		{
			loutputParameters = null;
		}
		if (Arguments.files != null && Arguments.files.Length != 0)
		{
			uploadTickets = new string[Arguments.files.Length];
		}
		else
		{
			uploadTickets = null;
		}
		if (Arguments.outputFiles != null && Arguments.outputFiles.Length != 0)
		{
			downloadTickets = new string[Arguments.outputFiles.Length];
		}
		else
		{
			downloadTickets = null;
		}
		updateFrequency = 500;
		this.getOutputsEvenOnError = getOutputsEvenOnError;
		pollFrequency = Arguments.pollFrequency;
	}

	private void FixWebServiceUrl(WebClientProtocol wcp)
	{
		int num = wcp.Url.LastIndexOf('/');
		if (num != -1)
		{
			string text = Arguments.server;
			if (text.IndexOf("://") == -1)
			{
				text = "http://" + text;
			}
			if (text[text.Length - 1] != '/')
			{
				text += "/";
			}
			wcp.Url = text + wcp.Url.Substring(num + 1);
		}
	}

	private string GetXferProgressString(long curUploaded, long totalSize, int elapsedTime)
	{
		if (elapsedTime == 0)
		{
			elapsedTime = 1;
		}
		long size = curUploaded * 100 / elapsedTime;
		return Rt.GetMemoryString(curUploaded) + "/" + Rt.GetMemoryString(totalSize) + " (" + Rt.GetMemoryString(size) + "/s)";
	}

	private void UpdateXferProgress(ref string curProgress, ref int lastUpdateTime, long curUploaded, long totalSize, int startTime, bool forceUpdate)
	{
		int tickCount = Environment.TickCount;
		if (forceUpdate || tickCount - lastUpdateTime >= updateFrequency)
		{
			int length = curProgress.Length;
			Console.Write(new string('\b', length));
			curProgress = GetXferProgressString(curUploaded, totalSize, tickCount - startTime).PadRight(length);
			Console.Write(curProgress);
			lastUpdateTime = tickCount;
		}
	}

	private string UploadFile(string fileName)
	{
		if (!File.Exists(fileName))
		{
			FrontCmd.ReportError(ExitCodes.FileNotFound, "Input file not found: " + fileName);
			return null;
		}
		long length;
		byte[] md5Hash;
		using (FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
		{
			length = fileStream.Length;
			md5Hash = Rt.CalcMd5Hash(fileStream);
		}
		string uploadTicket = string.Empty;
		long uploadedSize = 0L;
		string text = fa.StartFileUpload(fileName, length, md5Hash, ref uploadTicket, out uploadedSize);
		if (!string.IsNullOrEmpty(text))
		{
			FrontCmd.ReportError(ExitCodes.RemoteError, "Unable to start file upload: " + text);
			return null;
		}
		using (FileStream fileStream2 = new FileStream(fileName, FileMode.Open, FileAccess.Read))
		{
			fileStream2.Seek(uploadedSize, SeekOrigin.Begin);
			Console.Write("Uploading " + fileName + ": ");
			try
			{
				byte[] array = new byte[Arguments.chunkSize * 1024];
				int num = 0;
				long num2 = uploadedSize;
				int tickCount = Environment.TickCount;
				int lastUpdateTime = tickCount;
				string curProgress = string.Empty;
				do
				{
					num = fileStream2.Read(array, 0, array.Length);
					if (num != 0)
					{
						text = fa.UploadFileChunk(uploadTicket, array, 0, num);
						if (!string.IsNullOrEmpty(text))
						{
							Console.WriteLine();
							FrontCmd.ReportError(ExitCodes.RemoteError, "Upload error: " + text);
							return null;
						}
						num2 += num;
					}
					if (Arguments.verbose || num == 0)
					{
						UpdateXferProgress(ref curProgress, ref lastUpdateTime, num2, length, tickCount, num == 0);
					}
				}
				while (num != 0);
			}
			finally
			{
				Console.WriteLine();
			}
		}
		text = fa.EndFileUpload(uploadTicket);
		if (!string.IsNullOrEmpty(text))
		{
			FrontCmd.ReportError(ExitCodes.RemoteError, "Unable to end file upload: " + text);
			return null;
		}
		return uploadTicket;
	}

	private bool DownloadFile(string localFileName, string downloadTicket)
	{
		string text = localFileName;
		string text2 = fa.StartFileDownload(downloadTicket, out var serverFileName, out var serverFileSize, out var md5Hash);
		if (!string.IsNullOrEmpty(text2))
		{
			FrontCmd.ReportError(ExitCodes.RemoteError, "Unable to start file download: " + text2);
			return false;
		}
		if (string.IsNullOrEmpty(text))
		{
			text = serverFileName;
		}
		else if (Directory.Exists(text))
		{
			text = Path.Combine(text, serverFileName);
		}
		else if (text.EndsWith("\\"))
		{
			Directory.CreateDirectory(text);
			text = Path.Combine(text, serverFileName);
		}
		if (File.Exists(text) && !Arguments.overwrite)
		{
			FrontCmd.ReportError(ExitCodes.FileAlreadyExists, "Output file already exists: " + text + ". Use /overwrite parameter in order to replace any existing files.");
			return false;
		}
		using (FileStream fileStream = new FileStream(text, FileMode.Create, FileAccess.Write))
		{
			Console.Write("Downloading " + text + ": ");
			try
			{
				long num = 0L;
				int tickCount = Environment.TickCount;
				int lastUpdateTime = tickCount;
				string curProgress = string.Empty;
				do
				{
					text2 = fa.DownloadFileChunk(downloadTicket, num, Arguments.chunkSize * 1024, out var fileChunk, out var bytesRead);
					if (!string.IsNullOrEmpty(text2))
					{
						Console.WriteLine();
						FrontCmd.ReportError(ExitCodes.RemoteError, "Download error: " + text2);
						return false;
					}
					fileStream.Write(fileChunk, 0, bytesRead);
					num += bytesRead;
					if (Arguments.verbose || num >= serverFileSize)
					{
						UpdateXferProgress(ref curProgress, ref lastUpdateTime, num, serverFileSize, tickCount, num >= serverFileSize);
					}
				}
				while (num < serverFileSize);
			}
			finally
			{
				Console.WriteLine();
			}
		}
		byte[] a;
		using (FileStream stream = new FileStream(text, FileMode.Open, FileAccess.Read))
		{
			a = Rt.CalcMd5Hash(stream);
		}
		if (Rt.Compare(a, md5Hash) != 0)
		{
			FrontCmd.ReportError(ExitCodes.CorruptFile, "Hash code of the server file does not match that of the downloaded file");
			return false;
		}
		return true;
	}

	private bool CheckArguments()
	{
		if (Arguments.outputFiles != null && Arguments.outputFiles.Length != 0)
		{
			int i = 0;
			for (int num = Arguments.outputFiles.Length; i < num; i++)
			{
				string text = Arguments.outputFiles[i];
				if (!string.IsNullOrEmpty(text) && !Arguments.overwrite && File.Exists(text))
				{
					FrontCmd.ReportError(ExitCodes.FileAlreadyExists, "Output file already exists: " + text);
					return false;
				}
			}
		}
		return true;
	}

	private void UpdateExecFolderProgress(ref string curProgress, int startTime)
	{
		int length = curProgress.Length;
		Console.Write(new string('\b', length));
		curProgress = Rt.GetDurationString(Environment.TickCount - startTime).PadRight(length);
		Console.Write(curProgress);
	}

	private void UpdateExecFolderRemoteProgress(TaskProgressDescriptor descriptor, int startTime)
	{
		Console.WriteLine(Rt.GetDurationString(Environment.TickCount - startTime) + "\t" + Math.Round(descriptor.Progress, 0) + "%\t" + descriptor.Description);
	}

	protected override bool DoRun()
	{
		//IL_075d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0764: Expected O, but got Unknown
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_0789: Expected O, but got Unknown
		//IL_07a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b2: Expected O, but got Unknown
		bool flag = false;
		Console.WriteLine("ExecFolder of method '" + Arguments.method + "' on folder '" + Arguments.folder + "'...");
		WsFrontAdmin wsFrontAdmin = (fa = new WsFrontAdmin());
		try
		{
			try
			{
				((WebClientProtocol)fa).Credentials = CredentialCache.DefaultCredentials;
				((WebClientProtocol)fa).Timeout = Arguments.timeout * 60 * 1000;
				ServicePointManager.ServerCertificateValidationCallback = TrustAllCertificatePolicy.TrustAllCertificateCallback;
				ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				if (!CheckArguments())
				{
					return false;
				}
				FixWebServiceUrl((WebClientProtocol)(object)fa);
				((HttpWebClientProtocol)fa).CookieContainer = new CookieContainer();
				string tag = "FrontCmd";
				if (!string.IsNullOrEmpty(Arguments.openIdCertThumb) || !string.IsNullOrEmpty(Arguments.openIdSecret))
				{
					if (!string.IsNullOrEmpty(Arguments.openIdCertThumb) && !string.IsNullOrEmpty(Arguments.openIdSecret))
					{
						FrontCmd.ReportError(ExitCodes.LoginError, "Login error: you cannot use both certificate and client secret for OpenId");
						return false;
					}
					Console.WriteLine("OpenId " + ((!string.IsNullOrEmpty(Arguments.openIdCertThumb)) ? "Certificate" : "ClientSecret") + " authentication Mode");
					string text = string.Empty;
					try
					{
						OpenIdLoginManager openIdLoginManager = new OpenIdLoginManager();
						AuthLoginResult authLoginResult = null;
						authLoginResult = (string.IsNullOrEmpty(Arguments.openIdCertThumb) ? openIdLoginManager.LoginWithClientSecret(Arguments.server, Arguments.openIdSecret).Result : openIdLoginManager.LoginWithCertificate(Arguments.openIdCertThumb, Arguments.server).Result);
						if (authLoginResult.ResultCode != AuthLoginResultCode.Ok)
						{
							text = authLoginResult.ResultMessage;
							if (string.IsNullOrEmpty(text))
							{
								text = "OpenId login failed. Please check OpenId configuration and logs on the eFront server.";
							}
						}
						else
						{
							((HttpWebClientProtocol)fa).CookieContainer = openIdLoginManager.LoginCookie;
						}
					}
					catch (Exception ex)
					{
						text = ex.Message;
					}
					if (!string.IsNullOrEmpty(text))
					{
						FrontCmd.ReportError(ExitCodes.LoginError, "Login error: " + text);
						return false;
					}
				}
				else if (!string.IsNullOrEmpty(Arguments.userid))
				{
					Console.WriteLine("User/Password authentication Mode");
					string text2 = Arguments.password;
					string userid = Arguments.userid;
					string text3 = Arguments.passwordCard;
					bool flag2 = !string.IsNullOrEmpty(text3);
					if (text2.StartsWith("enc:") || text2.StartsWith("enc|"))
					{
						text2 = Rt.Decrypt(text2.Substring(4));
					}
					Console.WriteLine("Logging on user '" + userid + "' to server '" + Arguments.server + "'...");
					string text4;
					if (flag2)
					{
						if (text3.StartsWith("enc:") || text3.StartsWith("enc|"))
						{
							text3 = Rt.Decrypt(text3.Substring(4));
						}
						Console.WriteLine("Using 2nd authentication with password card...");
						text4 = fa.LoginWithCard(userid, text2, text3, tag);
					}
					else
					{
						text4 = fa.Login(userid, text2, tag);
					}
					if (!string.IsNullOrEmpty(text4))
					{
						FrontCmd.ReportError(ExitCodes.LoginError, "Login error: " + text4);
						return false;
					}
				}
				else
				{
					Console.WriteLine("Integrated authentication Mode");
					string error = "";
					if (string.IsNullOrEmpty(Environment.UserName))
					{
						error = "Could not retrieve current credentials";
					}
					else
					{
						Console.WriteLine("Logging on user '" + Environment.UserName + "' to server '" + Arguments.server + "'...");
						try
						{
							HttpLoginManager httpLoginManager = new HttpLoginManager(((WebClientProtocol)fa).Timeout / 1000);
							httpLoginManager.LoginProfile = LoginProfile.Create(Arguments.server, null, null, LoginMethod.Windows, tag);
							httpLoginManager.Login(out error);
							((HttpWebClientProtocol)fa).CookieContainer = httpLoginManager.LoginCookie;
						}
						catch (Exception ex2)
						{
							error = ex2.Message;
						}
					}
					if (!string.IsNullOrEmpty(error))
					{
						FrontCmd.ReportError(ExitCodes.LoginError, "Login error: " + error);
						return false;
					}
					Arguments.userid = Environment.UserName;
				}
				flag = true;
				if (Arguments.files != null && Arguments.files.Length != 0)
				{
					int i = 0;
					for (int num = Arguments.files.Length; i < num; i++)
					{
						string text5 = UploadFile(Arguments.files[i]);
						if (string.IsNullOrEmpty(text5))
						{
							return false;
						}
						uploadTickets[i] = text5;
					}
				}
				Console.Write("Executing folder: ");
				int tickCount = Environment.TickCount;
				string curProgress = string.Empty;
				if (Arguments.isAsync)
				{
					int taskId = fa.BeginExecFolder(Arguments.folder, Arguments.method, Arguments.parameters, loutputParameters, uploadTickets, downloadTickets);
					TaskProgressDescriptor taskProgressDescriptor = TryGetStatus(fa, taskId, 0);
					while (taskProgressDescriptor.Status == RtAsyncTaskStatusType.NotStarted || taskProgressDescriptor.Status == RtAsyncTaskStatusType.Running)
					{
						if (Arguments.verbose && taskProgressDescriptor.Progress < 100.0)
						{
							UpdateExecFolderRemoteProgress(taskProgressDescriptor, tickCount);
						}
						Thread.Sleep(pollFrequency);
						taskProgressDescriptor = TryGetStatus(fa, taskId, 0);
					}
					if (Arguments.verbose)
					{
						taskProgressDescriptor.Progress = 100.0;
						UpdateExecFolderRemoteProgress(taskProgressDescriptor, tickCount);
					}
					string serviceReturn = fa.EndExecFolder(taskId, ref loutputParameters, ref downloadTickets);
					HandleResults(serviceReturn);
				}
				else if (!string.IsNullOrEmpty(Arguments.frontCubeUrls))
				{
					fa.SetFrontCubeURLs(Arguments.frontCubeUrls);
				}
				else
				{
					if (Arguments.verbose)
					{
						execFolderException = null;
						fa.ExecFolderCompleted += fa_ExecFolderCompleted;
						fa.ExecFolderAsync(Arguments.folder, Arguments.method, Arguments.parameters, loutputParameters, uploadTickets, downloadTickets);
						int num2 = tickCount;
						while (!isExecFolderFinished)
						{
							if (Environment.TickCount - num2 >= updateFrequency)
							{
								UpdateExecFolderProgress(ref curProgress, tickCount);
								num2 = Environment.TickCount;
							}
							Thread.Sleep(updateFrequency);
						}
						if (execFolderException != null)
						{
							throw execFolderException;
						}
						return HandleResults(execFolderResult);
					}
					string serviceReturn2 = fa.ExecFolder(Arguments.folder, Arguments.method, Arguments.parameters, ref loutputParameters, uploadTickets, ref downloadTickets);
					UpdateExecFolderProgress(ref curProgress, tickCount);
					HandleResults(serviceReturn2);
				}
			}
			catch (Exception ex3)
			{
				if (ex3 is SoapException)
				{
					SoapException ex4 = (SoapException)ex3;
					if (ex4.Detail != null && ex4.Detail is XmlElement)
					{
						XmlElement val = (XmlElement)ex4.Detail;
						if (((XmlNode)val).FirstChild is XmlElement)
						{
							string exceptionMessage = null;
							string exceptionType = null;
							LoadExceptionDetails((XmlElement)((XmlNode)val).FirstChild, out exceptionType, out exceptionMessage);
							FrontCmd.ReportError(ExitCodes.RemoteError, exceptionMessage);
						}
						else
						{
							FrontCmd.ReportError(ExitCodes.RemoteError, ex3.Message);
						}
					}
					else
					{
						FrontCmd.ReportError(ExitCodes.RemoteError, ex3.Message);
					}
				}
				else
				{
					FrontCmd.ReportError(ExitCodes.RemoteError, ex3.Message);
				}
				return false;
			}
			finally
			{
				if (flag)
				{
					Console.WriteLine("Logging out user '" + Arguments.userid + "' from server '" + Arguments.server + "'...");
					fa.Logout();
				}
			}
		}
		finally
		{
			((IDisposable)wsFrontAdmin)?.Dispose();
		}
		return true;
	}

	private TaskProgressDescriptor TryGetStatus(WsFrontAdmin fa, int taskId, int retryCount)
	{
		try
		{
			return fa.GetTaskStatus(taskId);
		}
		catch (Exception arg)
		{
			if (retryCount == 0)
			{
				Console.WriteLine();
			}
			Console.WriteLine($"[Async] Still could not get status from server after #{retryCount + 1} attempt(s): {arg}");
			if (retryCount >= tryGetStatusRetriesPeriod.Length)
			{
				throw;
			}
			Console.WriteLine($"[Async] Will retry in {tryGetStatusRetriesPeriod[retryCount]}ms");
			Thread.Sleep(tryGetStatusRetriesPeriod[retryCount]);
			return TryGetStatus(fa, taskId, retryCount + 1);
		}
	}

	public static void LoadExceptionDetails(XmlElement node, out string exceptionType, out string exceptionMessage)
	{
		if (node == null)
		{
			throw new ArgumentNullException("node");
		}
		exceptionType = ((XmlNode)((XmlNode)node).Attributes["Type"]).Value;
		exceptionMessage = ((XmlNode)((XmlNode)node).Attributes["Message"]).Value;
	}

	private void fa_ExecFolderCompleted(object sender, ExecFolderCompletedEventArgs e)
	{
		if (e.Error != null)
		{
			execFolderException = e.Error;
		}
		else
		{
			loutputParameters = e.outputParameters;
			downloadTickets = e.downloadTickets;
			execFolderResult = e.Result;
		}
		isExecFolderFinished = true;
	}

	private bool HandleResults(string serviceReturn)
	{
		if (!string.IsNullOrEmpty(serviceReturn))
		{
			Console.WriteLine();
			FrontCmd.ReportError(ExitCodes.RemoteError, execFolderResult);
			if (!getOutputsEvenOnError)
			{
				return false;
			}
		}
		Console.WriteLine();
		if (Arguments.outputParameters != null && Arguments.outputParameters.Length != 0)
		{
			Console.WriteLine("Output parameters:");
			for (int i = 0; i < Arguments.outputParameters.Length; i++)
			{
				if (i < loutputParameters.Length)
				{
					loutputParameters[i] = Regex.Replace(loutputParameters[i], "(?<!\r)\n", "\r\n");
					Console.WriteLine(Arguments.outputParameters[i] + " => " + (string.IsNullOrEmpty(loutputParameters[i]) ? "<empty>" : loutputParameters[i]));
				}
			}
		}
		if (Arguments.downloadOutputFiles && downloadTickets != null && downloadTickets.Length != 0)
		{
			for (int j = 0; j < downloadTickets.Length; j++)
			{
				if (downloadTickets[j] == null || !(downloadTickets[j] != string.Empty))
				{
					continue;
				}
				string[] array = downloadTickets[j].Split(new char[1] { ';' });
				foreach (string downloadTicket in array)
				{
					if (!DownloadFile(Arguments.outputFiles[j], downloadTicket))
					{
						FrontCmd.ReportError(ExitCodes.OutputDownloadError, "ExecFolder:\r\n" + execFolderResult);
						return false;
					}
				}
			}
		}
		return string.IsNullOrEmpty(serviceReturn);
	}
}
