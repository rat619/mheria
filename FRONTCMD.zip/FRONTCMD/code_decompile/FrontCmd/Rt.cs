#define TRACE
using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace FrontCmd;

public class Rt
{
	private static byte[] rijndaelKey = new byte[32]
	{
		85, 111, 74, 121, 92, 2, 130, 76, 217, 203,
		76, 90, 183, 85, 181, 108, 244, 248, 177, 130,
		120, 142, 214, 87, 137, 213, 184, 190, 28, 224,
		247, 27
	};

	private static byte[] rijndaelIv = new byte[16]
	{
		207, 144, 20, 75, 205, 99, 217, 206, 109, 45,
		42, 5, 253, 94, 223, 37
	};

	public static bool IsEmpty(string s)
	{
		if (s != null)
		{
			return s.Length == 0;
		}
		return true;
	}

	public static byte[] CalcMd5Hash(Stream stream)
	{
		using MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
		mD5CryptoServiceProvider.Initialize();
		return mD5CryptoServiceProvider.ComputeHash(stream);
	}

	public static int Compare(byte[] a1, byte[] a2)
	{
		if (a1 == null)
		{
			return -1;
		}
		if (a2 == null)
		{
			return 1;
		}
		if (a1.Length < a2.Length)
		{
			return -1;
		}
		if (a1.Length > a2.Length)
		{
			return 1;
		}
		int i = 0;
		for (int num = a1.Length; i < num; i++)
		{
			byte b = a1[i];
			byte b2 = a2[i];
			if (b < b2)
			{
				return -1;
			}
			if (b > b2)
			{
				return 1;
			}
		}
		return 0;
	}

	public static string GetMemoryString(long size)
	{
		if (size < 1024)
		{
			return size + " bytes";
		}
		if (size < 1048576)
		{
			return ((decimal)size / 1024m).ToString("#.##") + "KB";
		}
		if (size < 1073741824)
		{
			return ((decimal)size / 1048576m).ToString("#.##") + "MB";
		}
		return ((decimal)size / 1073741824m).ToString("#.##") + "GB";
	}

	public static string GetDurationString(int ticks)
	{
		int num = ticks % 1000;
		int num2 = ticks / 1000;
		if (num2 == 0)
		{
			return num + "ms";
		}
		int num3 = num2 / 60;
		num2 %= 60;
		if (num3 == 0)
		{
			return num2 + "s " + num + "ms";
		}
		int num4 = num3 / 60;
		num3 %= 60;
		if (num4 == 0)
		{
			return num3 + "m " + num2 + "s " + num + "ms";
		}
		return num4 + "h " + num3 + "m " + num2 + "s " + num + "ms";
	}

	public static string Encrypt(string data)
	{
		try
		{
			ICryptoTransform transform = new AesCryptoServiceProvider().CreateEncryptor(rijndaelKey, rijndaelIv);
			UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
			MemoryStream memoryStream = new MemoryStream();
			CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
			byte[] bytes = unicodeEncoding.GetBytes(data);
			cryptoStream.Write(bytes, 0, bytes.Length);
			cryptoStream.FlushFinalBlock();
			return Convert.ToBase64String(memoryStream.ToArray());
		}
		catch (Exception ex)
		{
			Trace.WriteLine(ex.Message);
			return string.Empty;
		}
	}

	internal static string Decrypt(string data)
	{
		try
		{
			ICryptoTransform transform = new AesCryptoServiceProvider().CreateDecryptor(rijndaelKey, rijndaelIv);
			UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
			byte[] array = Convert.FromBase64String(data);
			CryptoStream cryptoStream = new CryptoStream(new MemoryStream(array), transform, CryptoStreamMode.Read);
			byte[] array2 = new byte[array.Length];
			int count = cryptoStream.Read(array2, 0, array2.Length);
			return unicodeEncoding.GetString(array2, 0, count);
		}
		catch (Exception ex)
		{
			Trace.WriteLine(ex.Message);
			return string.Empty;
		}
	}
}
