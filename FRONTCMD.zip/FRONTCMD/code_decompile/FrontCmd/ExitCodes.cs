namespace FrontCmd;

internal enum ExitCodes
{
	NoError,
	UnhandledException,
	CommandLineError,
	FileNotFound,
	FileAlreadyExists,
	LoginError,
	RemoteError,
	CorruptFile,
	OutputDownloadError
}
