using CommandLine;

namespace FrontCmd;

internal class CommandArguments : BaseArguments
{
	[DefaultArgument(ArgumentType.Required)]
	public Commands command;
}
