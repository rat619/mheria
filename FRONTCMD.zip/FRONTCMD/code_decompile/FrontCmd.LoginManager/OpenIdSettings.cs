using System;
using System.Configuration;

namespace FrontCmd.LoginManager;

public class OpenIdSettings
{
	private const string OpenIdLoginApi = "/openid/login";

	public string Server { get; set; }

	public Uri ResourceUri { get; set; }

	public string AuthorityUri { get; set; }

	public string ClientId { get; set; }

	public string Scope { get; set; }

	public bool UseResource { get; set; } = true;

	public static OpenIdSettings Load(string server)
	{
		OpenIdSettings openIdSettings = new OpenIdSettings();
		openIdSettings.Server = server;
		openIdSettings.ResourceUri = new Uri(new Uri(server), "/openid/login");
		openIdSettings.ClientId = ConfigurationManager.AppSettings["openid:clientId"];
		openIdSettings.AuthorityUri = ConfigurationManager.AppSettings["openid:authority"];
		openIdSettings.Scope = ConfigurationManager.AppSettings["openid:scope"];
		string value = ConfigurationManager.AppSettings["openid:useResource"];
		if (!string.IsNullOrEmpty(value) && bool.TryParse(value, out var result))
		{
			openIdSettings.UseResource = result;
		}
		if (string.IsNullOrEmpty(openIdSettings.AuthorityUri))
		{
			Console.WriteLine("Parameter openid:authority is missing. You must fill this parameter value in the .exe.config file");
			throw new Exception("Missing openid:authority setting");
		}
		if (string.IsNullOrEmpty(openIdSettings.ClientId))
		{
			Console.WriteLine("Parameter openid:clientId is missing. You must fill this parameter value in the .exe.config file");
			throw new Exception("Missing openid:clientId setting");
		}
		return openIdSettings;
	}
}
