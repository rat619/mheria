using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using efront.Runtime.Connector.Model;

namespace FrontCmd.LoginManager;

public class OpenIdLoginManager
{
	public CookieContainer LoginCookie { get; set; }

	public async Task<AuthLoginResult> LoginWithClientSecret(string server, string clientSecret)
	{
		string message;
		try
		{
			OpenIdSettings settings = OpenIdSettings.Load(server);
			if (string.IsNullOrEmpty(clientSecret))
			{
				Console.WriteLine("Parameter openid:clientSecret is missing. You must fill this parameter value in the .exe.config file");
				throw new Exception("Missing openid:clientSecret setting");
			}
			HttpClient httpClient = new HttpClient();
			DiscoveryDocumentRequest val = new DiscoveryDocumentRequest
			{
				Address = settings.AuthorityUri
			};
			val.Policy.ValidateEndpoints = false;
			val.Policy.ValidateIssuerName = false;
			DiscoveryDocumentResponse val2 = await HttpClientDiscoveryExtensions.GetDiscoveryDocumentAsync((HttpMessageInvoker)(object)httpClient, val, default(CancellationToken));
			if (((ProtocolResponse)val2).IsError)
			{
				Console.WriteLine("Error - " + ((ProtocolResponse)val2).Error);
				throw ((ProtocolResponse)val2).Exception ?? new Exception($"Error: {((ProtocolResponse)val2).ErrorType} - {((ProtocolResponse)val2).Error}");
			}
			TokenClientOptions val3 = new TokenClientOptions
			{
				Address = val2.TokenEndpoint,
				ClientId = settings.ClientId,
				ClientSecret = clientSecret
			};
			string text = null;
			if (!string.IsNullOrWhiteSpace(settings.Scope))
			{
				text = settings.Scope;
			}
			IDictionary<string, string> dictionary = new Dictionary<string, string>();
			if (settings.UseResource)
			{
				dictionary.Add("resource", settings.ResourceUri.ToString());
			}
			TokenResponse val4 = await new TokenClient((HttpMessageInvoker)(object)httpClient, val3).RequestClientCredentialsTokenAsync(text, dictionary, default(CancellationToken));
			return await LoginToEfrontUsingToken(server, settings.ResourceUri, val4.AccessToken, "Bearer");
		}
		catch (Exception ex)
		{
			message = ex.Message;
		}
		return new AuthLoginResult(AuthLoginResultCode.Failure, "Unexpected Error - Message: " + message);
	}

	public async Task<AuthLoginResult> LoginWithCertificate(string certificateThumbPrint, string server)
	{
		X509Store store = null;
		string text = "";
		try
		{
			OpenIdSettings settings = OpenIdSettings.Load(server);
			AuthenticationContext val = new AuthenticationContext(settings.AuthorityUri, false);
			store = new X509Store(StoreLocation.CurrentUser);
			Console.WriteLine($"Looking for certificate in Windows User Certificate Store matching thumbprint '{certificateThumbPrint}'");
			store.Open(OpenFlags.ReadOnly);
			X509Certificate2Collection x509Certificate2Collection = store.Certificates.Find(X509FindType.FindByTimeValid, DateTime.Now, validOnly: false).Find(X509FindType.FindByThumbprint, certificateThumbPrint, validOnly: false);
			if (x509Certificate2Collection.Count == 0)
			{
				return new AuthLoginResult(AuthLoginResultCode.Failure, "Could not find valid certificate matching the provided Thumbprint (" + certificateThumbPrint + "). Ensure the certificate is installed in the Windows Certificate Store for the current user running FrontCmd.");
			}
			X509Certificate2 x509Certificate = (from c in x509Certificate2Collection.OfType<X509Certificate2>()
				orderby c.NotBefore descending
				select c).First();
			Console.WriteLine(string.Format("Certificate found: \r\n{0}", x509Certificate.ToString().Replace("\r\n\r\n", "\r\n")));
			ClientAssertionCertificate val2 = new ClientAssertionCertificate(settings.ClientId, x509Certificate);
			Console.WriteLine($"Getting token from '{settings.AuthorityUri}' for resource '{settings.ResourceUri}'");
			AuthenticationResult val3 = await val.AcquireTokenAsync(settings.ResourceUri.ToString(), (IClientAssertionCertificate)(object)val2);
			return await LoginToEfrontUsingToken(server, settings.ResourceUri, val3.AccessToken, val3.AccessTokenType);
		}
		catch (Exception ex)
		{
			text = ex.Message;
		}
		finally
		{
			store?.Close();
		}
		return new AuthLoginResult(AuthLoginResultCode.Failure, "Unexpected Error - Message: " + text);
	}

	private async Task<AuthLoginResult> LoginToEfrontUsingToken(string server, Uri resourceUri, string accessToken, string accessTokenType)
	{
		string message;
		try
		{
			if (string.IsNullOrEmpty(accessToken))
			{
				return new AuthLoginResult(AuthLoginResultCode.Failure, "Unable to retrieve an access token");
			}
			Console.WriteLine("Access Token Received");
			Console.WriteLine("Logging on using received access token to server '" + server + "'...");
			LoginCookie = new CookieContainer();
			HttpClientHandler handler = new HttpClientHandler
			{
				CookieContainer = LoginCookie
			};
			try
			{
				HttpClient httpClient = new HttpClient((HttpMessageHandler)(object)handler);
				try
				{
					httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(accessTokenType, accessToken);
					HttpResponseMessage val = await httpClient.GetAsync(resourceUri);
					if (val.IsSuccessStatusCode)
					{
						string s = await val.Content.ReadAsStringAsync();
						MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(s));
						if (!(((XmlObjectSerializer)new DataContractJsonSerializer(typeof(AuthLoginResult))).ReadObject((Stream)memoryStream) is AuthLoginResult result))
						{
							return new AuthLoginResult(AuthLoginResultCode.Failure, "Could not parse login response");
						}
						return result;
					}
					return new AuthLoginResult(AuthLoginResultCode.Failure, $"Error occurred during login process - Status Code : '{val.StatusCode}'");
				}
				finally
				{
					((IDisposable)httpClient)?.Dispose();
				}
			}
			finally
			{
				((IDisposable)handler)?.Dispose();
			}
		}
		catch (Exception ex)
		{
			message = ex.Message;
		}
		return new AuthLoginResult(AuthLoginResultCode.Failure, "Unexpected Error - Message: " + message);
	}
}
