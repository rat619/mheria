using System.CodeDom.Compiler;

namespace FrontCmd.efront1;

[GeneratedCode("System.Web.Services", "4.8.3752.0")]
public delegate void StartFileDownloadCompletedEventHandler(object sender, StartFileDownloadCompletedEventArgs e);
