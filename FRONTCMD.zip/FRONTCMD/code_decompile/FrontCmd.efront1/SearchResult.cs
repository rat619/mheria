using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrontCmd.efront1;

[Serializable]
[XmlInclude(typeof(DbObjectSearchResult))]
[XmlInclude(typeof(FileSearchResult))]
[GeneratedCode("System.Xml", "4.8.3752.0")]
[DebuggerStepThrough]
[DesignerCategory("code")]
[XmlType(Namespace = "http://efront.fr/webservices/")]
public class SearchResult : SearchResultBase
{
	private string iconField;

	private bool openOutsideField;

	private DateTime lastOpenedDateField;

	private SearchResultType resultTypeField;

	public string Icon
	{
		get
		{
			return iconField;
		}
		set
		{
			iconField = value;
		}
	}

	public bool OpenOutside
	{
		get
		{
			return openOutsideField;
		}
		set
		{
			openOutsideField = value;
		}
	}

	public DateTime LastOpenedDate
	{
		get
		{
			return lastOpenedDateField;
		}
		set
		{
			lastOpenedDateField = value;
		}
	}

	public SearchResultType ResultType
	{
		get
		{
			return resultTypeField;
		}
		set
		{
			resultTypeField = value;
		}
	}
}
