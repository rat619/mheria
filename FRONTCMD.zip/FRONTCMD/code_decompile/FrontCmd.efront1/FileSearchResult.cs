using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrontCmd.efront1;

[Serializable]
[GeneratedCode("System.Xml", "4.8.3752.0")]
[DebuggerStepThrough]
[DesignerCategory("code")]
[XmlType(Namespace = "http://efront.fr/webservices/")]
public class FileSearchResult : SearchResult
{
	private string pathField;

	private string linkUrlField;

	private DbObjectSearchResult attachedDBObjectField;

	private bool isAttachmentField;

	private long sizeInBytesField;

	public string Path
	{
		get
		{
			return pathField;
		}
		set
		{
			pathField = value;
		}
	}

	public string LinkUrl
	{
		get
		{
			return linkUrlField;
		}
		set
		{
			linkUrlField = value;
		}
	}

	public DbObjectSearchResult AttachedDBObject
	{
		get
		{
			return attachedDBObjectField;
		}
		set
		{
			attachedDBObjectField = value;
		}
	}

	public bool IsAttachment
	{
		get
		{
			return isAttachmentField;
		}
		set
		{
			isAttachmentField = value;
		}
	}

	public long SizeInBytes
	{
		get
		{
			return sizeInBytesField;
		}
		set
		{
			sizeInBytesField = value;
		}
	}
}
