using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrontCmd.efront1;

[Serializable]
[XmlInclude(typeof(SearchResult))]
[XmlInclude(typeof(DbObjectSearchResult))]
[XmlInclude(typeof(FileSearchResult))]
[GeneratedCode("System.Xml", "4.8.3752.0")]
[DebuggerStepThrough]
[DesignerCategory("code")]
[XmlType(Namespace = "http://efront.fr/webservices/")]
public abstract class SearchResultBase
{
	private string iQIDField;

	private string iQRegionIDField;

	private string displayNameField;

	private string resultTypeCaptionField;

	private float scoreField;

	private string descriptionField;

	private DateTime lastModificationDateField;

	private string lastModificationUserField;

	private string[] missingTermsField;

	private string urlField;

	public string IQID
	{
		get
		{
			return iQIDField;
		}
		set
		{
			iQIDField = value;
		}
	}

	public string IQRegionID
	{
		get
		{
			return iQRegionIDField;
		}
		set
		{
			iQRegionIDField = value;
		}
	}

	public string DisplayName
	{
		get
		{
			return displayNameField;
		}
		set
		{
			displayNameField = value;
		}
	}

	public string ResultTypeCaption
	{
		get
		{
			return resultTypeCaptionField;
		}
		set
		{
			resultTypeCaptionField = value;
		}
	}

	public float Score
	{
		get
		{
			return scoreField;
		}
		set
		{
			scoreField = value;
		}
	}

	public string Description
	{
		get
		{
			return descriptionField;
		}
		set
		{
			descriptionField = value;
		}
	}

	public DateTime LastModificationDate
	{
		get
		{
			return lastModificationDateField;
		}
		set
		{
			lastModificationDateField = value;
		}
	}

	public string LastModificationUser
	{
		get
		{
			return lastModificationUserField;
		}
		set
		{
			lastModificationUserField = value;
		}
	}

	public string[] MissingTerms
	{
		get
		{
			return missingTermsField;
		}
		set
		{
			missingTermsField = value;
		}
	}

	public string Url
	{
		get
		{
			return urlField;
		}
		set
		{
			urlField = value;
		}
	}
}
