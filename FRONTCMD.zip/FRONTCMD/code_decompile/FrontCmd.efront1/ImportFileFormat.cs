using System;
using System.CodeDom.Compiler;
using System.Xml.Serialization;

namespace FrontCmd.efront1;

[Serializable]
[GeneratedCode("System.Xml", "4.8.3752.0")]
[XmlType(Namespace = "http://efront.fr/webservices/")]
public enum ImportFileFormat
{
	Xls,
	Xlsx,
	Csv
}
