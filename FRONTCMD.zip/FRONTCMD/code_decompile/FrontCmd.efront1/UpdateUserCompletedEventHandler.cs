using System.CodeDom.Compiler;
using System.ComponentModel;

namespace FrontCmd.efront1;

[GeneratedCode("System.Web.Services", "4.8.3752.0")]
public delegate void UpdateUserCompletedEventHandler(object sender, AsyncCompletedEventArgs e);
