using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Serialization;
using FrontCmd.Properties;

namespace FrontCmd.efront1;

[GeneratedCode("System.Web.Services", "4.8.3752.0")]
[DebuggerStepThrough]
[DesignerCategory("code")]
[WebServiceBinding(Name = "WsFrontAdminSoap", Namespace = "http://efront.fr/webservices/")]
[XmlInclude(typeof(SearchResultBase))]
[XmlInclude(typeof(object[][]))]
public class WsFrontAdmin : SoapHttpClientProtocol
{
	private SendOrPostCallback LoginOperationCompleted;

	private SendOrPostCallback LoginWithCardOperationCompleted;

	private SendOrPostCallback IntegratedLoginOperationCompleted;

	private SendOrPostCallback LogoutOperationCompleted;

	private SendOrPostCallback CreateUserOperationCompleted;

	private SendOrPostCallback SetFrontCubeURLsOperationCompleted;

	private SendOrPostCallback UpdateUserOperationCompleted;

	private SendOrPostCallback UpdateUserProfilesOperationCompleted;

	private SendOrPostCallback DeleteUserOperationCompleted;

	private SendOrPostCallback GetFrontletHtmlOperationCompleted;

	private SendOrPostCallback GetReportXMLOperationCompleted;

	private SendOrPostCallback StartFileUploadOperationCompleted;

	private SendOrPostCallback UploadFileChunkOperationCompleted;

	private SendOrPostCallback EndFileUploadOperationCompleted;

	private SendOrPostCallback FileUploadWithHashCheckOperationCompleted;

	private SendOrPostCallback FileUploadOperationCompleted;

	private SendOrPostCallback StartFileDownloadOperationCompleted;

	private SendOrPostCallback DownloadFileChunkOperationCompleted;

	private SendOrPostCallback ExecFolderWithExceptionOnErrorOperationCompleted;

	private SendOrPostCallback ExecFolderWithLoginOperationCompleted;

	private SendOrPostCallback ExecFolderOperationCompleted;

	private SendOrPostCallback BeginExecFolderOperationCompleted;

	private SendOrPostCallback GetTaskStatusOperationCompleted;

	private SendOrPostCallback EndExecFolderOperationCompleted;

	private SendOrPostCallback ExecFolderNoParamOperationCompleted;

	private SendOrPostCallback ExecReportWithLoginOperationCompleted;

	private SendOrPostCallback ExecReportOperationCompleted;

	private SendOrPostCallback ExecReportCSVWithLoginOperationCompleted;

	private SendOrPostCallback ExecReportCSVOperationCompleted;

	private SendOrPostCallback ExecImportWithLoginOperationCompleted;

	private SendOrPostCallback ExecImportOperationCompleted;

	private SendOrPostCallback ExecImportCSVWithLoginOperationCompleted;

	private SendOrPostCallback ExecImportCSVOperationCompleted;

	private SendOrPostCallback ExecWebEdgeImportWithLoginOperationCompleted;

	private SendOrPostCallback ExecWebEdgeImportOperationCompleted;

	private SendOrPostCallback ExecWebEdgeImportCSVWithLoginOperationCompleted;

	private SendOrPostCallback ExecWebEdgeImportCSVOperationCompleted;

	private SendOrPostCallback SearchOperationCompleted;

	private bool useDefaultCredentialsSetExplicitly;

	public string Url
	{
		get
		{
			return ((WebClientProtocol)this).Url;
		}
		set
		{
			if (IsLocalFileSystemWebService(((WebClientProtocol)this).Url) && !useDefaultCredentialsSetExplicitly && !IsLocalFileSystemWebService(value))
			{
				((WebClientProtocol)this).UseDefaultCredentials = false;
			}
			((WebClientProtocol)this).Url = value;
		}
	}

	public bool UseDefaultCredentials
	{
		get
		{
			return ((WebClientProtocol)this).UseDefaultCredentials;
		}
		set
		{
			((WebClientProtocol)this).UseDefaultCredentials = value;
			useDefaultCredentialsSetExplicitly = true;
		}
	}

	public event LoginCompletedEventHandler LoginCompleted;

	public event LoginWithCardCompletedEventHandler LoginWithCardCompleted;

	public event IntegratedLoginCompletedEventHandler IntegratedLoginCompleted;

	public event LogoutCompletedEventHandler LogoutCompleted;

	public event CreateUserCompletedEventHandler CreateUserCompleted;

	public event SetFrontCubeURLsCompletedEventHandler SetFrontCubeURLsCompleted;

	public event UpdateUserCompletedEventHandler UpdateUserCompleted;

	public event UpdateUserProfilesCompletedEventHandler UpdateUserProfilesCompleted;

	public event DeleteUserCompletedEventHandler DeleteUserCompleted;

	public event GetFrontletHtmlCompletedEventHandler GetFrontletHtmlCompleted;

	public event GetReportXMLCompletedEventHandler GetReportXMLCompleted;

	public event StartFileUploadCompletedEventHandler StartFileUploadCompleted;

	public event UploadFileChunkCompletedEventHandler UploadFileChunkCompleted;

	public event EndFileUploadCompletedEventHandler EndFileUploadCompleted;

	public event FileUploadWithHashCheckCompletedEventHandler FileUploadWithHashCheckCompleted;

	public event FileUploadCompletedEventHandler FileUploadCompleted;

	public event StartFileDownloadCompletedEventHandler StartFileDownloadCompleted;

	public event DownloadFileChunkCompletedEventHandler DownloadFileChunkCompleted;

	public event ExecFolderWithExceptionOnErrorCompletedEventHandler ExecFolderWithExceptionOnErrorCompleted;

	public event ExecFolderWithLoginCompletedEventHandler ExecFolderWithLoginCompleted;

	public event ExecFolderCompletedEventHandler ExecFolderCompleted;

	public event BeginExecFolderCompletedEventHandler BeginExecFolderCompleted;

	public event GetTaskStatusCompletedEventHandler GetTaskStatusCompleted;

	public event EndExecFolderCompletedEventHandler EndExecFolderCompleted;

	public event ExecFolderNoParamCompletedEventHandler ExecFolderNoParamCompleted;

	public event ExecReportWithLoginCompletedEventHandler ExecReportWithLoginCompleted;

	public event ExecReportCompletedEventHandler ExecReportCompleted;

	public event ExecReportCSVWithLoginCompletedEventHandler ExecReportCSVWithLoginCompleted;

	public event ExecReportCSVCompletedEventHandler ExecReportCSVCompleted;

	public event ExecImportWithLoginCompletedEventHandler ExecImportWithLoginCompleted;

	public event ExecImportCompletedEventHandler ExecImportCompleted;

	public event ExecImportCSVWithLoginCompletedEventHandler ExecImportCSVWithLoginCompleted;

	public event ExecImportCSVCompletedEventHandler ExecImportCSVCompleted;

	public event ExecWebEdgeImportWithLoginCompletedEventHandler ExecWebEdgeImportWithLoginCompleted;

	public event ExecWebEdgeImportCompletedEventHandler ExecWebEdgeImportCompleted;

	public event ExecWebEdgeImportCSVWithLoginCompletedEventHandler ExecWebEdgeImportCSVWithLoginCompleted;

	public event ExecWebEdgeImportCSVCompletedEventHandler ExecWebEdgeImportCSVCompleted;

	public event SearchCompletedEventHandler SearchCompleted;

	public WsFrontAdmin()
	{
		Url = Settings.Default.FrontCmd_efront1_WsFrontAdmin;
		if (IsLocalFileSystemWebService(Url))
		{
			UseDefaultCredentials = true;
			useDefaultCredentialsSetExplicitly = false;
		}
		else
		{
			useDefaultCredentialsSetExplicitly = true;
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string Login(string LoginName, string Password, string Tag)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("Login", new object[3] { LoginName, Password, Tag })[0];
	}

	public void LoginAsync(string LoginName, string Password, string Tag)
	{
		LoginAsync(LoginName, Password, Tag, null);
	}

	public void LoginAsync(string LoginName, string Password, string Tag, object userState)
	{
		if (LoginOperationCompleted == null)
		{
			LoginOperationCompleted = OnLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("Login", new object[3] { LoginName, Password, Tag }, LoginOperationCompleted, userState);
	}

	private void OnLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.LoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.LoginCompleted(this, new LoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string LoginWithCard(string loginName, string password, string passwordCard, string Tag)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("LoginWithCard", new object[4] { loginName, password, passwordCard, Tag })[0];
	}

	public void LoginWithCardAsync(string loginName, string password, string passwordCard, string Tag)
	{
		LoginWithCardAsync(loginName, password, passwordCard, Tag, null);
	}

	public void LoginWithCardAsync(string loginName, string password, string passwordCard, string Tag, object userState)
	{
		if (LoginWithCardOperationCompleted == null)
		{
			LoginWithCardOperationCompleted = OnLoginWithCardOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("LoginWithCard", new object[4] { loginName, password, passwordCard, Tag }, LoginWithCardOperationCompleted, userState);
	}

	private void OnLoginWithCardOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.LoginWithCardCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.LoginWithCardCompleted(this, new LoginWithCardCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string IntegratedLogin()
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("IntegratedLogin", new object[0])[0];
	}

	public void IntegratedLoginAsync()
	{
		IntegratedLoginAsync(null);
	}

	public void IntegratedLoginAsync(object userState)
	{
		if (IntegratedLoginOperationCompleted == null)
		{
			IntegratedLoginOperationCompleted = OnIntegratedLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("IntegratedLogin", new object[0], IntegratedLoginOperationCompleted, userState);
	}

	private void OnIntegratedLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.IntegratedLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.IntegratedLoginCompleted(this, new IntegratedLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string Logout()
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("Logout", new object[0])[0];
	}

	public void LogoutAsync()
	{
		LogoutAsync(null);
	}

	public void LogoutAsync(object userState)
	{
		if (LogoutOperationCompleted == null)
		{
			LogoutOperationCompleted = OnLogoutOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("Logout", new object[0], LogoutOperationCompleted, userState);
	}

	private void OnLogoutOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.LogoutCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.LogoutCompleted(this, new LogoutCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public void CreateUser(string UserID, string FirstName, string LastName, string Password, string Profile)
	{
		((SoapHttpClientProtocol)this).Invoke("CreateUser", new object[5] { UserID, FirstName, LastName, Password, Profile });
	}

	public void CreateUserAsync(string UserID, string FirstName, string LastName, string Password, string Profile)
	{
		CreateUserAsync(UserID, FirstName, LastName, Password, Profile, null);
	}

	public void CreateUserAsync(string UserID, string FirstName, string LastName, string Password, string Profile, object userState)
	{
		if (CreateUserOperationCompleted == null)
		{
			CreateUserOperationCompleted = OnCreateUserOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("CreateUser", new object[5] { UserID, FirstName, LastName, Password, Profile }, CreateUserOperationCompleted, userState);
	}

	private void OnCreateUserOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.CreateUserCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.CreateUserCompleted(this, new AsyncCompletedEventArgs(((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public void SetFrontCubeURLs(string urls)
	{
		((SoapHttpClientProtocol)this).Invoke("SetFrontCubeURLs", new object[1] { urls });
	}

	public void SetFrontCubeURLsAsync(string urls)
	{
		SetFrontCubeURLsAsync(urls, null);
	}

	public void SetFrontCubeURLsAsync(string urls, object userState)
	{
		if (SetFrontCubeURLsOperationCompleted == null)
		{
			SetFrontCubeURLsOperationCompleted = OnSetFrontCubeURLsOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("SetFrontCubeURLs", new object[1] { urls }, SetFrontCubeURLsOperationCompleted, userState);
	}

	private void OnSetFrontCubeURLsOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.SetFrontCubeURLsCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.SetFrontCubeURLsCompleted(this, new AsyncCompletedEventArgs(((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public void UpdateUser(string UserID, string FirstName, string LastName, string Password, string Profile)
	{
		((SoapHttpClientProtocol)this).Invoke("UpdateUser", new object[5] { UserID, FirstName, LastName, Password, Profile });
	}

	public void UpdateUserAsync(string UserID, string FirstName, string LastName, string Password, string Profile)
	{
		UpdateUserAsync(UserID, FirstName, LastName, Password, Profile, null);
	}

	public void UpdateUserAsync(string UserID, string FirstName, string LastName, string Password, string Profile, object userState)
	{
		if (UpdateUserOperationCompleted == null)
		{
			UpdateUserOperationCompleted = OnUpdateUserOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("UpdateUser", new object[5] { UserID, FirstName, LastName, Password, Profile }, UpdateUserOperationCompleted, userState);
	}

	private void OnUpdateUserOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.UpdateUserCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.UpdateUserCompleted(this, new AsyncCompletedEventArgs(((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public void UpdateUserProfiles(string UserID, string[] Profiles)
	{
		((SoapHttpClientProtocol)this).Invoke("UpdateUserProfiles", new object[2] { UserID, Profiles });
	}

	public void UpdateUserProfilesAsync(string UserID, string[] Profiles)
	{
		UpdateUserProfilesAsync(UserID, Profiles, null);
	}

	public void UpdateUserProfilesAsync(string UserID, string[] Profiles, object userState)
	{
		if (UpdateUserProfilesOperationCompleted == null)
		{
			UpdateUserProfilesOperationCompleted = OnUpdateUserProfilesOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("UpdateUserProfiles", new object[2] { UserID, Profiles }, UpdateUserProfilesOperationCompleted, userState);
	}

	private void OnUpdateUserProfilesOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.UpdateUserProfilesCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.UpdateUserProfilesCompleted(this, new AsyncCompletedEventArgs(((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public void DeleteUser(string UserID)
	{
		((SoapHttpClientProtocol)this).Invoke("DeleteUser", new object[1] { UserID });
	}

	public void DeleteUserAsync(string UserID)
	{
		DeleteUserAsync(UserID, null);
	}

	public void DeleteUserAsync(string UserID, object userState)
	{
		if (DeleteUserOperationCompleted == null)
		{
			DeleteUserOperationCompleted = OnDeleteUserOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("DeleteUser", new object[1] { UserID }, DeleteUserOperationCompleted, userState);
	}

	private void OnDeleteUserOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.DeleteUserCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.DeleteUserCompleted(this, new AsyncCompletedEventArgs(((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string GetFrontletHtml(string name)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("GetFrontletHtml", new object[1] { name })[0];
	}

	public void GetFrontletHtmlAsync(string name)
	{
		GetFrontletHtmlAsync(name, null);
	}

	public void GetFrontletHtmlAsync(string name, object userState)
	{
		if (GetFrontletHtmlOperationCompleted == null)
		{
			GetFrontletHtmlOperationCompleted = OnGetFrontletHtmlOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("GetFrontletHtml", new object[1] { name }, GetFrontletHtmlOperationCompleted, userState);
	}

	private void OnGetFrontletHtmlOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.GetFrontletHtmlCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.GetFrontletHtmlCompleted(this, new GetFrontletHtmlCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string GetReportXML(string reportPath, string reportParams)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("GetReportXML", new object[2] { reportPath, reportParams })[0];
	}

	public void GetReportXMLAsync(string reportPath, string reportParams)
	{
		GetReportXMLAsync(reportPath, reportParams, null);
	}

	public void GetReportXMLAsync(string reportPath, string reportParams, object userState)
	{
		if (GetReportXMLOperationCompleted == null)
		{
			GetReportXMLOperationCompleted = OnGetReportXMLOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("GetReportXML", new object[2] { reportPath, reportParams }, GetReportXMLOperationCompleted, userState);
	}

	private void OnGetReportXMLOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.GetReportXMLCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.GetReportXMLCompleted(this, new GetReportXMLCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string StartFileUpload(string localFileName, long fileSize, [XmlElement(DataType = "base64Binary")] byte[] md5Hash, ref string uploadTicket, out long uploadedSize)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("StartFileUpload", new object[4] { localFileName, fileSize, md5Hash, uploadTicket });
		uploadTicket = (string)array[1];
		uploadedSize = (long)array[2];
		return (string)array[0];
	}

	public void StartFileUploadAsync(string localFileName, long fileSize, byte[] md5Hash, string uploadTicket)
	{
		StartFileUploadAsync(localFileName, fileSize, md5Hash, uploadTicket, null);
	}

	public void StartFileUploadAsync(string localFileName, long fileSize, byte[] md5Hash, string uploadTicket, object userState)
	{
		if (StartFileUploadOperationCompleted == null)
		{
			StartFileUploadOperationCompleted = OnStartFileUploadOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("StartFileUpload", new object[4] { localFileName, fileSize, md5Hash, uploadTicket }, StartFileUploadOperationCompleted, userState);
	}

	private void OnStartFileUploadOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.StartFileUploadCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.StartFileUploadCompleted(this, new StartFileUploadCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string UploadFileChunk(string uploadTicket, [XmlElement(DataType = "base64Binary")] byte[] fileChunk, int offset, int count)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("UploadFileChunk", new object[4] { uploadTicket, fileChunk, offset, count })[0];
	}

	public void UploadFileChunkAsync(string uploadTicket, byte[] fileChunk, int offset, int count)
	{
		UploadFileChunkAsync(uploadTicket, fileChunk, offset, count, null);
	}

	public void UploadFileChunkAsync(string uploadTicket, byte[] fileChunk, int offset, int count, object userState)
	{
		if (UploadFileChunkOperationCompleted == null)
		{
			UploadFileChunkOperationCompleted = OnUploadFileChunkOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("UploadFileChunk", new object[4] { uploadTicket, fileChunk, offset, count }, UploadFileChunkOperationCompleted, userState);
	}

	private void OnUploadFileChunkOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.UploadFileChunkCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.UploadFileChunkCompleted(this, new UploadFileChunkCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string EndFileUpload(string uploadTicket)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("EndFileUpload", new object[1] { uploadTicket })[0];
	}

	public void EndFileUploadAsync(string uploadTicket)
	{
		EndFileUploadAsync(uploadTicket, null);
	}

	public void EndFileUploadAsync(string uploadTicket, object userState)
	{
		if (EndFileUploadOperationCompleted == null)
		{
			EndFileUploadOperationCompleted = OnEndFileUploadOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("EndFileUpload", new object[1] { uploadTicket }, EndFileUploadOperationCompleted, userState);
	}

	private void OnEndFileUploadOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.EndFileUploadCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.EndFileUploadCompleted(this, new EndFileUploadCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string FileUploadWithHashCheck(string localFileName, [XmlElement(DataType = "base64Binary")] byte[] md5Hash, [XmlElement(DataType = "base64Binary")] byte[] fileContent, ref string uploadTicket)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("FileUploadWithHashCheck", new object[4] { localFileName, md5Hash, fileContent, uploadTicket });
		uploadTicket = (string)array[1];
		return (string)array[0];
	}

	public void FileUploadWithHashCheckAsync(string localFileName, byte[] md5Hash, byte[] fileContent, string uploadTicket)
	{
		FileUploadWithHashCheckAsync(localFileName, md5Hash, fileContent, uploadTicket, null);
	}

	public void FileUploadWithHashCheckAsync(string localFileName, byte[] md5Hash, byte[] fileContent, string uploadTicket, object userState)
	{
		if (FileUploadWithHashCheckOperationCompleted == null)
		{
			FileUploadWithHashCheckOperationCompleted = OnFileUploadWithHashCheckOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("FileUploadWithHashCheck", new object[4] { localFileName, md5Hash, fileContent, uploadTicket }, FileUploadWithHashCheckOperationCompleted, userState);
	}

	private void OnFileUploadWithHashCheckOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.FileUploadWithHashCheckCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.FileUploadWithHashCheckCompleted(this, new FileUploadWithHashCheckCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string FileUpload(string localFileName, [XmlElement(DataType = "base64Binary")] byte[] fileContent, ref string uploadTicket)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("FileUpload", new object[3] { localFileName, fileContent, uploadTicket });
		uploadTicket = (string)array[1];
		return (string)array[0];
	}

	public void FileUploadAsync(string localFileName, byte[] fileContent, string uploadTicket)
	{
		FileUploadAsync(localFileName, fileContent, uploadTicket, null);
	}

	public void FileUploadAsync(string localFileName, byte[] fileContent, string uploadTicket, object userState)
	{
		if (FileUploadOperationCompleted == null)
		{
			FileUploadOperationCompleted = OnFileUploadOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("FileUpload", new object[3] { localFileName, fileContent, uploadTicket }, FileUploadOperationCompleted, userState);
	}

	private void OnFileUploadOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.FileUploadCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.FileUploadCompleted(this, new FileUploadCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string StartFileDownload(string downloadTicket, out string serverFileName, out long serverFileSize, [XmlElement(DataType = "base64Binary")] out byte[] md5Hash)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("StartFileDownload", new object[1] { downloadTicket });
		serverFileName = (string)array[1];
		serverFileSize = (long)array[2];
		md5Hash = (byte[])array[3];
		return (string)array[0];
	}

	public void StartFileDownloadAsync(string downloadTicket)
	{
		StartFileDownloadAsync(downloadTicket, null);
	}

	public void StartFileDownloadAsync(string downloadTicket, object userState)
	{
		if (StartFileDownloadOperationCompleted == null)
		{
			StartFileDownloadOperationCompleted = OnStartFileDownloadOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("StartFileDownload", new object[1] { downloadTicket }, StartFileDownloadOperationCompleted, userState);
	}

	private void OnStartFileDownloadOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.StartFileDownloadCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.StartFileDownloadCompleted(this, new StartFileDownloadCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string DownloadFileChunk(string downloadTicket, long offset, int chunkSize, [XmlElement(DataType = "base64Binary")] out byte[] fileChunk, out int bytesRead)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("DownloadFileChunk", new object[3] { downloadTicket, offset, chunkSize });
		fileChunk = (byte[])array[1];
		bytesRead = (int)array[2];
		return (string)array[0];
	}

	public void DownloadFileChunkAsync(string downloadTicket, long offset, int chunkSize)
	{
		DownloadFileChunkAsync(downloadTicket, offset, chunkSize, null);
	}

	public void DownloadFileChunkAsync(string downloadTicket, long offset, int chunkSize, object userState)
	{
		if (DownloadFileChunkOperationCompleted == null)
		{
			DownloadFileChunkOperationCompleted = OnDownloadFileChunkOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("DownloadFileChunk", new object[3] { downloadTicket, offset, chunkSize }, DownloadFileChunkOperationCompleted, userState);
	}

	private void OnDownloadFileChunkOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.DownloadFileChunkCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.DownloadFileChunkCompleted(this, new DownloadFileChunkCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecFolderWithExceptionOnError(string folderName, string methodName, string[] parameters, ref string[] outputParameters, string[] uploadTickets, ref string[] downloadTickets)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecFolderWithExceptionOnError", new object[6] { folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets });
		outputParameters = (string[])array[1];
		downloadTickets = (string[])array[2];
		return (string)array[0];
	}

	public void ExecFolderWithExceptionOnErrorAsync(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets)
	{
		ExecFolderWithExceptionOnErrorAsync(folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets, null);
	}

	public void ExecFolderWithExceptionOnErrorAsync(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets, object userState)
	{
		if (ExecFolderWithExceptionOnErrorOperationCompleted == null)
		{
			ExecFolderWithExceptionOnErrorOperationCompleted = OnExecFolderWithExceptionOnErrorOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecFolderWithExceptionOnError", new object[6] { folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets }, ExecFolderWithExceptionOnErrorOperationCompleted, userState);
	}

	private void OnExecFolderWithExceptionOnErrorOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecFolderWithExceptionOnErrorCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecFolderWithExceptionOnErrorCompleted(this, new ExecFolderWithExceptionOnErrorCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecFolderWithLogin(string loginName, string password, string folderName, string methodName, string[] parameters, ref string[] outputParameters, string[] uploadTickets, ref string[] downloadTickets)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecFolderWithLogin", new object[8] { loginName, password, folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets });
		outputParameters = (string[])array[1];
		downloadTickets = (string[])array[2];
		return (string)array[0];
	}

	public void ExecFolderWithLoginAsync(string loginName, string password, string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets)
	{
		ExecFolderWithLoginAsync(loginName, password, folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets, null);
	}

	public void ExecFolderWithLoginAsync(string loginName, string password, string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets, object userState)
	{
		if (ExecFolderWithLoginOperationCompleted == null)
		{
			ExecFolderWithLoginOperationCompleted = OnExecFolderWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecFolderWithLogin", new object[8] { loginName, password, folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets }, ExecFolderWithLoginOperationCompleted, userState);
	}

	private void OnExecFolderWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecFolderWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecFolderWithLoginCompleted(this, new ExecFolderWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecFolder(string folderName, string methodName, string[] parameters, ref string[] outputParameters, string[] uploadTickets, ref string[] downloadTickets)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecFolder", new object[6] { folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets });
		outputParameters = (string[])array[1];
		downloadTickets = (string[])array[2];
		return (string)array[0];
	}

	public void ExecFolderAsync(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets)
	{
		ExecFolderAsync(folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets, null);
	}

	public void ExecFolderAsync(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets, object userState)
	{
		if (ExecFolderOperationCompleted == null)
		{
			ExecFolderOperationCompleted = OnExecFolderOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecFolder", new object[6] { folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets }, ExecFolderOperationCompleted, userState);
	}

	private void OnExecFolderOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecFolderCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecFolderCompleted(this, new ExecFolderCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public int BeginExecFolder(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets)
	{
		return (int)((SoapHttpClientProtocol)this).Invoke("BeginExecFolder", new object[6] { folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets })[0];
	}

	public void BeginExecFolderAsync(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets)
	{
		BeginExecFolderAsync(folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets, null);
	}

	public void BeginExecFolderAsync(string folderName, string methodName, string[] parameters, string[] outputParameters, string[] uploadTickets, string[] downloadTickets, object userState)
	{
		if (BeginExecFolderOperationCompleted == null)
		{
			BeginExecFolderOperationCompleted = OnBeginExecFolderOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("BeginExecFolder", new object[6] { folderName, methodName, parameters, outputParameters, uploadTickets, downloadTickets }, BeginExecFolderOperationCompleted, userState);
	}

	private void OnBeginExecFolderOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.BeginExecFolderCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.BeginExecFolderCompleted(this, new BeginExecFolderCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public TaskProgressDescriptor GetTaskStatus(int taskId)
	{
		return (TaskProgressDescriptor)((SoapHttpClientProtocol)this).Invoke("GetTaskStatus", new object[1] { taskId })[0];
	}

	public void GetTaskStatusAsync(int taskId)
	{
		GetTaskStatusAsync(taskId, null);
	}

	public void GetTaskStatusAsync(int taskId, object userState)
	{
		if (GetTaskStatusOperationCompleted == null)
		{
			GetTaskStatusOperationCompleted = OnGetTaskStatusOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("GetTaskStatus", new object[1] { taskId }, GetTaskStatusOperationCompleted, userState);
	}

	private void OnGetTaskStatusOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.GetTaskStatusCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.GetTaskStatusCompleted(this, new GetTaskStatusCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string EndExecFolder(int taskId, ref string[] outputParameters, ref string[] downloadTickets)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("EndExecFolder", new object[3] { taskId, outputParameters, downloadTickets });
		outputParameters = (string[])array[1];
		downloadTickets = (string[])array[2];
		return (string)array[0];
	}

	public void EndExecFolderAsync(int taskId, string[] outputParameters, string[] downloadTickets)
	{
		EndExecFolderAsync(taskId, outputParameters, downloadTickets, null);
	}

	public void EndExecFolderAsync(int taskId, string[] outputParameters, string[] downloadTickets, object userState)
	{
		if (EndExecFolderOperationCompleted == null)
		{
			EndExecFolderOperationCompleted = OnEndExecFolderOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("EndExecFolder", new object[3] { taskId, outputParameters, downloadTickets }, EndExecFolderOperationCompleted, userState);
	}

	private void OnEndExecFolderOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.EndExecFolderCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.EndExecFolderCompleted(this, new EndExecFolderCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecFolderNoParam(string folderName, string methodName)
	{
		return (string)((SoapHttpClientProtocol)this).Invoke("ExecFolderNoParam", new object[2] { folderName, methodName })[0];
	}

	public void ExecFolderNoParamAsync(string folderName, string methodName)
	{
		ExecFolderNoParamAsync(folderName, methodName, null);
	}

	public void ExecFolderNoParamAsync(string folderName, string methodName, object userState)
	{
		if (ExecFolderNoParamOperationCompleted == null)
		{
			ExecFolderNoParamOperationCompleted = OnExecFolderNoParamOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecFolderNoParam", new object[2] { folderName, methodName }, ExecFolderNoParamOperationCompleted, userState);
	}

	private void OnExecFolderNoParamOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecFolderNoParamCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecFolderNoParamCompleted(this, new ExecFolderNoParamCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecReportWithLogin(string loginName, string password, string reportPath, string inputParams, out string outputFileName, [XmlElement(DataType = "base64Binary")] out byte[] outputFileContent)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecReportWithLogin", new object[4] { loginName, password, reportPath, inputParams });
		outputFileName = (string)array[1];
		outputFileContent = (byte[])array[2];
		return (string)array[0];
	}

	public void ExecReportWithLoginAsync(string loginName, string password, string reportPath, string inputParams)
	{
		ExecReportWithLoginAsync(loginName, password, reportPath, inputParams, null);
	}

	public void ExecReportWithLoginAsync(string loginName, string password, string reportPath, string inputParams, object userState)
	{
		if (ExecReportWithLoginOperationCompleted == null)
		{
			ExecReportWithLoginOperationCompleted = OnExecReportWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecReportWithLogin", new object[4] { loginName, password, reportPath, inputParams }, ExecReportWithLoginOperationCompleted, userState);
	}

	private void OnExecReportWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecReportWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecReportWithLoginCompleted(this, new ExecReportWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecReport(string reportPath, string inputParams, out string outputFileName, [XmlElement(DataType = "base64Binary")] out byte[] outputFileContent)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecReport", new object[2] { reportPath, inputParams });
		outputFileName = (string)array[1];
		outputFileContent = (byte[])array[2];
		return (string)array[0];
	}

	public void ExecReportAsync(string reportPath, string inputParams)
	{
		ExecReportAsync(reportPath, inputParams, null);
	}

	public void ExecReportAsync(string reportPath, string inputParams, object userState)
	{
		if (ExecReportOperationCompleted == null)
		{
			ExecReportOperationCompleted = OnExecReportOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecReport", new object[2] { reportPath, inputParams }, ExecReportOperationCompleted, userState);
	}

	private void OnExecReportOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecReportCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecReportCompleted(this, new ExecReportCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecReportCSVWithLogin(string loginName, string password, string reportPath, string inputParams, [XmlArrayItem("ArrayOfAnyType")][XmlArrayItem(NestingLevel = 1)] out object[][] outputContent)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecReportCSVWithLogin", new object[4] { loginName, password, reportPath, inputParams });
		outputContent = (object[][])array[1];
		return (string)array[0];
	}

	public void ExecReportCSVWithLoginAsync(string loginName, string password, string reportPath, string inputParams)
	{
		ExecReportCSVWithLoginAsync(loginName, password, reportPath, inputParams, null);
	}

	public void ExecReportCSVWithLoginAsync(string loginName, string password, string reportPath, string inputParams, object userState)
	{
		if (ExecReportCSVWithLoginOperationCompleted == null)
		{
			ExecReportCSVWithLoginOperationCompleted = OnExecReportCSVWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecReportCSVWithLogin", new object[4] { loginName, password, reportPath, inputParams }, ExecReportCSVWithLoginOperationCompleted, userState);
	}

	private void OnExecReportCSVWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecReportCSVWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecReportCSVWithLoginCompleted(this, new ExecReportCSVWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecReportCSV(string reportPath, string inputParams, [XmlArrayItem("ArrayOfAnyType")][XmlArrayItem(NestingLevel = 1)] out object[][] outputContent)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecReportCSV", new object[2] { reportPath, inputParams });
		outputContent = (object[][])array[1];
		return (string)array[0];
	}

	public void ExecReportCSVAsync(string reportPath, string inputParams)
	{
		ExecReportCSVAsync(reportPath, inputParams, null);
	}

	public void ExecReportCSVAsync(string reportPath, string inputParams, object userState)
	{
		if (ExecReportCSVOperationCompleted == null)
		{
			ExecReportCSVOperationCompleted = OnExecReportCSVOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecReportCSV", new object[2] { reportPath, inputParams }, ExecReportCSVOperationCompleted, userState);
	}

	private void OnExecReportCSVOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecReportCSVCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecReportCSVCompleted(this, new ExecReportCSVCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecImportWithLogin(string loginName, string password, string importTemplateName, [XmlElement(DataType = "base64Binary")] byte[] inputFileContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecImportWithLogin", new object[4] { loginName, password, importTemplateName, inputFileContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecImportWithLoginAsync(string loginName, string password, string importTemplateName, byte[] inputFileContent)
	{
		ExecImportWithLoginAsync(loginName, password, importTemplateName, inputFileContent, null);
	}

	public void ExecImportWithLoginAsync(string loginName, string password, string importTemplateName, byte[] inputFileContent, object userState)
	{
		if (ExecImportWithLoginOperationCompleted == null)
		{
			ExecImportWithLoginOperationCompleted = OnExecImportWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecImportWithLogin", new object[4] { loginName, password, importTemplateName, inputFileContent }, ExecImportWithLoginOperationCompleted, userState);
	}

	private void OnExecImportWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecImportWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecImportWithLoginCompleted(this, new ExecImportWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecImport(string importTemplateName, [XmlElement(DataType = "base64Binary")] byte[] inputFileContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecImport", new object[2] { importTemplateName, inputFileContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecImportAsync(string importTemplateName, byte[] inputFileContent)
	{
		ExecImportAsync(importTemplateName, inputFileContent, null);
	}

	public void ExecImportAsync(string importTemplateName, byte[] inputFileContent, object userState)
	{
		if (ExecImportOperationCompleted == null)
		{
			ExecImportOperationCompleted = OnExecImportOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecImport", new object[2] { importTemplateName, inputFileContent }, ExecImportOperationCompleted, userState);
	}

	private void OnExecImportOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecImportCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecImportCompleted(this, new ExecImportCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecImportCSVWithLogin(string loginName, string password, string importTemplateName, [XmlArrayItem("ArrayOfAnyType")][XmlArrayItem(NestingLevel = 1)] object[][] inputContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecImportCSVWithLogin", new object[4] { loginName, password, importTemplateName, inputContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecImportCSVWithLoginAsync(string loginName, string password, string importTemplateName, object[][] inputContent)
	{
		ExecImportCSVWithLoginAsync(loginName, password, importTemplateName, inputContent, null);
	}

	public void ExecImportCSVWithLoginAsync(string loginName, string password, string importTemplateName, object[][] inputContent, object userState)
	{
		if (ExecImportCSVWithLoginOperationCompleted == null)
		{
			ExecImportCSVWithLoginOperationCompleted = OnExecImportCSVWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecImportCSVWithLogin", new object[4] { loginName, password, importTemplateName, inputContent }, ExecImportCSVWithLoginOperationCompleted, userState);
	}

	private void OnExecImportCSVWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecImportCSVWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecImportCSVWithLoginCompleted(this, new ExecImportCSVWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecImportCSV(string importTemplateName, [XmlArrayItem("ArrayOfAnyType")][XmlArrayItem(NestingLevel = 1)] object[][] inputContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecImportCSV", new object[2] { importTemplateName, inputContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecImportCSVAsync(string importTemplateName, object[][] inputContent)
	{
		ExecImportCSVAsync(importTemplateName, inputContent, null);
	}

	public void ExecImportCSVAsync(string importTemplateName, object[][] inputContent, object userState)
	{
		if (ExecImportCSVOperationCompleted == null)
		{
			ExecImportCSVOperationCompleted = OnExecImportCSVOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecImportCSV", new object[2] { importTemplateName, inputContent }, ExecImportCSVOperationCompleted, userState);
	}

	private void OnExecImportCSVOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecImportCSVCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecImportCSVCompleted(this, new ExecImportCSVCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecWebEdgeImportWithLogin(string loginName, string password, ImportFileFormat inputFileFormat, [XmlElement(DataType = "base64Binary")] byte[] inputFileContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecWebEdgeImportWithLogin", new object[4] { loginName, password, inputFileFormat, inputFileContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecWebEdgeImportWithLoginAsync(string loginName, string password, ImportFileFormat inputFileFormat, byte[] inputFileContent)
	{
		ExecWebEdgeImportWithLoginAsync(loginName, password, inputFileFormat, inputFileContent, null);
	}

	public void ExecWebEdgeImportWithLoginAsync(string loginName, string password, ImportFileFormat inputFileFormat, byte[] inputFileContent, object userState)
	{
		if (ExecWebEdgeImportWithLoginOperationCompleted == null)
		{
			ExecWebEdgeImportWithLoginOperationCompleted = OnExecWebEdgeImportWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecWebEdgeImportWithLogin", new object[4] { loginName, password, inputFileFormat, inputFileContent }, ExecWebEdgeImportWithLoginOperationCompleted, userState);
	}

	private void OnExecWebEdgeImportWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecWebEdgeImportWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecWebEdgeImportWithLoginCompleted(this, new ExecWebEdgeImportWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecWebEdgeImport(ImportFileFormat inputFileFormat, [XmlElement(DataType = "base64Binary")] byte[] inputFileContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecWebEdgeImport", new object[2] { inputFileFormat, inputFileContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecWebEdgeImportAsync(ImportFileFormat inputFileFormat, byte[] inputFileContent)
	{
		ExecWebEdgeImportAsync(inputFileFormat, inputFileContent, null);
	}

	public void ExecWebEdgeImportAsync(ImportFileFormat inputFileFormat, byte[] inputFileContent, object userState)
	{
		if (ExecWebEdgeImportOperationCompleted == null)
		{
			ExecWebEdgeImportOperationCompleted = OnExecWebEdgeImportOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecWebEdgeImport", new object[2] { inputFileFormat, inputFileContent }, ExecWebEdgeImportOperationCompleted, userState);
	}

	private void OnExecWebEdgeImportOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecWebEdgeImportCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecWebEdgeImportCompleted(this, new ExecWebEdgeImportCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecWebEdgeImportCSVWithLogin(string loginName, string password, [XmlArrayItem("ArrayOfAnyType")][XmlArrayItem(NestingLevel = 1)] object[][] inputContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecWebEdgeImportCSVWithLogin", new object[3] { loginName, password, inputContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecWebEdgeImportCSVWithLoginAsync(string loginName, string password, object[][] inputContent)
	{
		ExecWebEdgeImportCSVWithLoginAsync(loginName, password, inputContent, null);
	}

	public void ExecWebEdgeImportCSVWithLoginAsync(string loginName, string password, object[][] inputContent, object userState)
	{
		if (ExecWebEdgeImportCSVWithLoginOperationCompleted == null)
		{
			ExecWebEdgeImportCSVWithLoginOperationCompleted = OnExecWebEdgeImportCSVWithLoginOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecWebEdgeImportCSVWithLogin", new object[3] { loginName, password, inputContent }, ExecWebEdgeImportCSVWithLoginOperationCompleted, userState);
	}

	private void OnExecWebEdgeImportCSVWithLoginOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecWebEdgeImportCSVWithLoginCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecWebEdgeImportCSVWithLoginCompleted(this, new ExecWebEdgeImportCSVWithLoginCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public string ExecWebEdgeImportCSV([XmlArrayItem("ArrayOfAnyType")][XmlArrayItem(NestingLevel = 1)] object[][] inputContent, out string outputLog)
	{
		object[] array = ((SoapHttpClientProtocol)this).Invoke("ExecWebEdgeImportCSV", new object[1] { inputContent });
		outputLog = (string)array[1];
		return (string)array[0];
	}

	public void ExecWebEdgeImportCSVAsync(object[][] inputContent)
	{
		ExecWebEdgeImportCSVAsync(inputContent, null);
	}

	public void ExecWebEdgeImportCSVAsync(object[][] inputContent, object userState)
	{
		if (ExecWebEdgeImportCSVOperationCompleted == null)
		{
			ExecWebEdgeImportCSVOperationCompleted = OnExecWebEdgeImportCSVOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("ExecWebEdgeImportCSV", new object[1] { inputContent }, ExecWebEdgeImportCSVOperationCompleted, userState);
	}

	private void OnExecWebEdgeImportCSVOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.ExecWebEdgeImportCSVCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.ExecWebEdgeImportCSVCompleted(this, new ExecWebEdgeImportCSVCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	[SoapDocumentMethod(/*Could not decode attribute arguments.*/)]
	public SearchResult[] Search(string searchTerm, bool useExactsearch, SearchResultType searchResult, DocumentFilterType fileType)
	{
		return (SearchResult[])((SoapHttpClientProtocol)this).Invoke("Search", new object[4] { searchTerm, useExactsearch, searchResult, fileType })[0];
	}

	public void SearchAsync(string searchTerm, bool useExactsearch, SearchResultType searchResult, DocumentFilterType fileType)
	{
		SearchAsync(searchTerm, useExactsearch, searchResult, fileType, null);
	}

	public void SearchAsync(string searchTerm, bool useExactsearch, SearchResultType searchResult, DocumentFilterType fileType, object userState)
	{
		if (SearchOperationCompleted == null)
		{
			SearchOperationCompleted = OnSearchOperationCompleted;
		}
		((SoapHttpClientProtocol)this).InvokeAsync("Search", new object[4] { searchTerm, useExactsearch, searchResult, fileType }, SearchOperationCompleted, userState);
	}

	private void OnSearchOperationCompleted(object arg)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		if (this.SearchCompleted != null)
		{
			InvokeCompletedEventArgs e = (InvokeCompletedEventArgs)arg;
			this.SearchCompleted(this, new SearchCompletedEventArgs(e.Results, ((AsyncCompletedEventArgs)(object)e).Error, ((AsyncCompletedEventArgs)(object)e).Cancelled, ((AsyncCompletedEventArgs)(object)e).UserState));
		}
	}

	public void CancelAsync(object userState)
	{
		((HttpWebClientProtocol)this).CancelAsync(userState);
	}

	private bool IsLocalFileSystemWebService(string url)
	{
		if (url == null || url == string.Empty)
		{
			return false;
		}
		Uri uri = new Uri(url);
		if (uri.Port >= 1024 && string.Compare(uri.Host, "localHost", StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		return false;
	}
}
