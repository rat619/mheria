using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

namespace FrontCmd.efront1;

[GeneratedCode("System.Web.Services", "4.8.3752.0")]
[DebuggerStepThrough]
[DesignerCategory("code")]
public class SearchCompletedEventArgs : AsyncCompletedEventArgs
{
	private object[] results;

	public SearchResult[] Result
	{
		get
		{
			RaiseExceptionIfNecessary();
			return (SearchResult[])results[0];
		}
	}

	internal SearchCompletedEventArgs(object[] results, Exception exception, bool cancelled, object userState)
		: base(exception, cancelled, userState)
	{
		this.results = results;
	}
}
