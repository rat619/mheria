using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyFileVersion("5.2.271.0")]
[assembly: AssemblyInformationalVersion("5.2.271.0+sha.ac1b176ad1")]
[assembly: AssemblyTitle("FrontCmd")]
[assembly: AssemblyDescription("EFront 3rd party environment")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("eFront")]
[assembly: AssemblyProduct("eFront Runtime tools")]
[assembly: AssemblyCopyright("Copyright © eFront 2009-2022")]
[assembly: AssemblyMetadata("efront.Version.Public", "5.2.271.0")]
[assembly: AssemblyMetadata("efront.Version.Internal", "5.2.271.0+sha.ac1b176ad1")]
[assembly: AssemblyVersion("5.2.0.0")]
