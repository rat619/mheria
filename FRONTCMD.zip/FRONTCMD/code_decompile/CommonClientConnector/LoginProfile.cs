using System;

namespace CommonClientConnector;

public class LoginProfile : IMyICloneable, ICloneable, IComparable
{
	public string ServerBaseUrl { get; set; }

	public string User { get; set; }

	public string Password { get; set; }

	public bool UseWindowsAuthent { get; set; }

	public bool UseTokenAuthent { get; set; }

	public string Tag { get; set; }

	public string AppVersion { get; set; }

	public static LoginProfile Create(string serverUrl, string user, string password, LoginMethod loginMethod, string tag = null, string appVersion = null)
	{
		bool useWindowsAuthent = loginMethod == LoginMethod.Windows;
		bool useTokenAuthent = loginMethod == LoginMethod.Token;
		return new LoginProfile
		{
			ServerBaseUrl = serverUrl,
			User = user,
			Password = password,
			AppVersion = appVersion,
			UseWindowsAuthent = useWindowsAuthent,
			UseTokenAuthent = useTokenAuthent,
			Tag = tag
		};
	}

	public object Clone()
	{
		LoginMethod loginMethod = LoginMethod.LoginAndPassword;
		if (UseWindowsAuthent)
		{
			loginMethod = LoginMethod.Windows;
		}
		else if (UseTokenAuthent)
		{
			loginMethod = LoginMethod.Token;
		}
		return Create(ServerBaseUrl, User, Password, loginMethod, "FrontCmd");
	}

	public int CompareTo(object obj)
	{
		if (!(obj is LoginProfile loginProfile))
		{
			throw new ArgumentException("Object to sort is not Login");
		}
		return string.Compare(ServerBaseUrl, loginProfile.ServerBaseUrl, StringComparison.Ordinal);
	}
}
