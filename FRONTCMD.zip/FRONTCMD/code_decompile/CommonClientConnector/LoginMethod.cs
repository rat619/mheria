namespace CommonClientConnector;

public enum LoginMethod
{
	LoginAndPassword,
	Windows,
	Token
}
