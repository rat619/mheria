using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using CommonClientConnector.Adfs;

namespace CommonClientConnector;

public class AdfsLoginManager : IAdfsLoginManager
{
	private readonly AdfsResponseWifExtractor wifExtractor;

	public AdfsLoginManager(AdfsResponseWifExtractor wifExtractor)
	{
		this.wifExtractor = wifExtractor;
	}

	public async Task<ResponseLoginInfo> LoginToAdfs(Uri serverUri, ResponseLoginInfo responseLoginInfo, CookieContainer cookieContainer)
	{
		AdfsWifParameters adfsWifParameters = wifExtractor.ExtractWifParametersFromResponse(responseLoginInfo.ResponseText);
		if (string.IsNullOrEmpty(adfsWifParameters.Wa))
		{
			throw new Exception("Unable to login thru ADFS - The WA parameter is empty");
		}
		if (string.IsNullOrEmpty(adfsWifParameters.WResult))
		{
			throw new Exception("Unable to login thru ADFS - The WRESULT parameter is empty");
		}
		if (string.IsNullOrEmpty(adfsWifParameters.WCtx))
		{
			throw new Exception("Unable to login thru ADFS - The WCTX parameter is empty");
		}
		return await PostRequestBackToInitialWebsite(serverUri, adfsWifParameters, cookieContainer);
	}

	private async Task<ResponseLoginInfo> PostRequestBackToInitialWebsite(Uri serverUri, AdfsWifParameters wifParameters, CookieContainer cookie)
	{
		FormUrlEncodedContent val = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>)new List<KeyValuePair<string, string>>
		{
			new KeyValuePair<string, string>("wa", wifParameters.Wa),
			new KeyValuePair<string, string>("wresult", wifParameters.WResult),
			new KeyValuePair<string, string>("wctx", wifParameters.WCtx)
		});
		HttpClientHandler val2 = new HttpClientHandler
		{
			AllowAutoRedirect = true,
			CookieContainer = cookie,
			UseDefaultCredentials = true
		};
		HttpClient client = new HttpClient((HttpMessageHandler)(object)val2);
		try
		{
			HttpResponseMessage response = await client.PostAsync(serverUri, (HttpContent)(object)val).ConfigureAwait(continueOnCapturedContext: false);
			try
			{
				if (response.StatusCode != HttpStatusCode.OK)
				{
					throw new Exception($"ADFS Authentication failed - Received HTTP response status {response.StatusCode} from server");
				}
				string responseText = await response.Content.ReadAsStringAsync().ConfigureAwait(continueOnCapturedContext: false);
				string antiCsrfToken = "";
				IEnumerable<string> source = default(IEnumerable<string>);
				if (((HttpHeaders)response.Headers).TryGetValues("AntiCSRF", ref source))
				{
					antiCsrfToken = source.First();
				}
				return new ResponseLoginInfo(response.RequestMessage.RequestUri, antiCsrfToken, responseText)
				{
					StatusCode = response.StatusCode
				};
			}
			finally
			{
				((IDisposable)response)?.Dispose();
			}
		}
		finally
		{
			((IDisposable)client)?.Dispose();
		}
	}
}
