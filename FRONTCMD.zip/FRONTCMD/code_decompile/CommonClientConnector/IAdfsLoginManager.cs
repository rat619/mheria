using System;
using System.Net;
using System.Threading.Tasks;

namespace CommonClientConnector;

public interface IAdfsLoginManager
{
	Task<ResponseLoginInfo> LoginToAdfs(Uri serverUri, ResponseLoginInfo responseLoginInfo, CookieContainer cookieContainer);
}
