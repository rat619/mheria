using System.Net;
using System.Threading.Tasks;

namespace CommonClientConnector;

public interface IHttpLoginManager : ILoginManager
{
	int TimeOut { get; set; }

	Task<HttpWebRequest> PostRequest(string urlSuffix, string nonEncodedParams, bool writeToLog = true, int timeout = 0);
}
