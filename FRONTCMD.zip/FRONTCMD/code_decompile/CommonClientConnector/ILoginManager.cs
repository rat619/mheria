using System;
using System.Net;
using System.Threading.Tasks;

namespace CommonClientConnector;

public interface ILoginManager
{
	CookieContainer LoginCookie { get; set; }

	string AntiCsrfToken { get; set; }

	LoginProfile LoginProfile { get; set; }

	Uri LoginRequestUri { get; set; }

	bool Login(out string error);

	Task<string> LoginAsync();
}
