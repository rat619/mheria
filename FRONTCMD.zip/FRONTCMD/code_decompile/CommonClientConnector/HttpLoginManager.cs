using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using CommonClientConnector.Adfs;
using CommonClientConnector.Exceptions;

namespace CommonClientConnector;

public class HttpLoginManager : IHttpLoginManager, ILoginManager
{
	private static class MyHttpUtility
	{
		public static string UrlDecode(string url)
		{
			return HttpUtility.UrlDecode(url);
		}

		public static string UrlEncode(string url)
		{
			return HttpUtility.UrlEncode(url);
		}
	}

	private const string Post = "POST";

	public const string InvalidIdentifierPasswordMessage = "The username or password you entered is incorrect.";

	public const string PasswordExpiredMessage = "Your password has expired. You need to connect to eFront in a browser in order to change your password.";

	public const string InvalidAppVersion = "Your version of the application isn't compatible with the server";

	public const string AccountLocked = "This account is locked.";

	private readonly Encoding encoding;

	public int TimeOut { get; set; }

	public CookieContainer LoginCookie { get; set; }

	public string AntiCsrfToken { get; set; }

	public LoginProfile LoginProfile { get; set; }

	public Uri LoginRequestUri { get; set; }

	public HttpLoginManager(int timeOut)
	{
		TimeOut = timeOut;
		encoding = new UTF8Encoding();
	}

	public async Task<string> LoginAsync()
	{
		_ = 4;
		try
		{
			HttpWebRequest httpWebRequest;
			try
			{
				if (LoginProfile.UseWindowsAuthent)
				{
					httpWebRequest = await PostRequestForLogin("/login/iis", "").ConfigureAwait(continueOnCapturedContext: false);
				}
				else if (LoginProfile.UseTokenAuthent)
				{
					string encodedParams = $"token={MyHttpUtility.UrlEncode(LoginProfile.User)}";
					httpWebRequest = await PostRequestForLogin("/login/efronttoken", encodedParams).ConfigureAwait(continueOnCapturedContext: false);
				}
				else
				{
					string text = $"FORMLOGINid={MyHttpUtility.UrlEncode(LoginProfile.User)}&FORMLOGINpwd={MyHttpUtility.UrlEncode(LoginProfile.Password)}&FORMLOGINAppVersion={MyHttpUtility.UrlEncode(LoginProfile.AppVersion)}";
					if (!string.IsNullOrEmpty(LoginProfile.Tag))
					{
						text += $"&FORMTag={LoginProfile.Tag}";
					}
					httpWebRequest = await PostRequestForLogin("/Login.ashx", text);
				}
			}
			catch (Exception innerException)
			{
				throw new LoginConnectionException("Cannot access Server " + LoginProfile.ServerBaseUrl, innerException);
			}
			LoginCookie = new CookieContainer();
			httpWebRequest.CookieContainer = LoginCookie;
			httpWebRequest.Credentials = CredentialCache.DefaultNetworkCredentials;
			ResponseLoginInfo responseLoginInfo = await ResponseLogin(httpWebRequest, TimeOut);
			if (responseLoginInfo.Url != null && responseLoginInfo.Url.AbsolutePath.StartsWith("/adfs"))
			{
				AdfsLoginManager adfsLoginManager = new AdfsLoginManager(new AdfsResponseWifExtractor());
				Console.WriteLine("ADFS detected - Start ADFS auth");
				responseLoginInfo = await adfsLoginManager.LoginToAdfs(new Uri(LoginProfile.ServerBaseUrl), responseLoginInfo, LoginCookie);
			}
			string text2 = MyHttpUtility.UrlDecode(responseLoginInfo.Url.Query);
			if (text2.Contains("incorrect"))
			{
				throw new LoginConnectionException("The username or password you entered is incorrect.");
			}
			if (text2.Contains("This account is locked."))
			{
				throw new LoginConnectionException("This account is locked.");
			}
			if (text2.Contains("Warning"))
			{
				throw new Exception(text2);
			}
			if (responseLoginInfo.Url.ToString().Contains("ChangePwd.aspx"))
			{
				throw new LoginConnectionException("Your password has expired. You need to connect to eFront in a browser in order to change your password.");
			}
			AntiCsrfToken = responseLoginInfo.AntiCsrfToken;
		}
		catch (LoginConnectionException ex)
		{
			return ex.Message;
		}
		catch (Exception ex2)
		{
			return "Cannot login: " + ex2.Message;
		}
		Task.Delay(2000).Wait();
		return "";
	}

	public bool Login(out string error)
	{
		error = LoginAsync().Result;
		return string.IsNullOrEmpty(error);
	}

	public Task<HttpWebRequest> PostRequest(string urlSuffix, string nonEncodedParams, bool writeToLog = true, int timeout = 0)
	{
		return Request(urlSuffix, "Efrontarg=" + MyHttpUtility.UrlEncode(nonEncodedParams), useCookie: true, timeout);
	}

	private Task<HttpWebRequest> PostRequestForLogin(string urlSuffix, string encodedParams)
	{
		return Request(urlSuffix, encodedParams, useCookie: false);
	}

	private async Task<HttpWebRequest> Request(string urlSuffix, string encodedParams, bool useCookie, int timeout = 0)
	{
		int timeOut = ((timeout > 0) ? timeout : TimeOut);
		HttpWebRequest request = (HttpWebRequest)WebRequest.Create(LoginProfile.ServerBaseUrl + urlSuffix);
		request.Method = "POST";
		if (useCookie)
		{
			request.CookieContainer = LoginCookie;
		}
		request.Credentials = CredentialCache.DefaultNetworkCredentials;
		request.ContentType = "application/x-www-form-urlencoded";
		if (!string.IsNullOrEmpty(AntiCsrfToken))
		{
			request.Headers["AntiCSRF"] = AntiCsrfToken;
		}
		request.UserAgent = "eFront agent";
		byte[] bytes = SetRequestDetails(request, timeOut, LoginProfile.ServerBaseUrl, encodedParams, encoding);
		using (Stream stream = await GetResponseStream(request))
		{
			if (stream == null)
			{
				throw new WebException("Request timeout");
			}
			stream.Write(bytes, 0, bytes.Length);
		}
		LoginRequestUri = request.RequestUri;
		return request;
	}

	private async Task<ResponseLoginInfo> ResponseLogin(WebRequest request, int timeOut)
	{
		using WebResponse webResponse = await GetResponse(request);
		if (webResponse == null)
		{
			throw new EfrontWebRequestResponseException("Response timeout");
		}
		if (((HttpWebResponse)webResponse).StatusCode != HttpStatusCode.OK)
		{
			throw new EfrontWebRequestResponseException("Response Login status code not Ok");
		}
		string responseText = "";
		using (Stream stream = webResponse.GetResponseStream())
		{
			using StreamReader streamReader = new StreamReader(stream, Encoding.UTF8);
			responseText = streamReader.ReadToEnd();
		}
		return new ResponseLoginInfo(webResponse.ResponseUri, webResponse.Headers["AntiCSRF"], responseText);
	}

	private static Task<WebResponse> GetResponse(WebRequest request)
	{
		TaskCompletionSource<WebResponse> taskCompletionSource = new TaskCompletionSource<WebResponse>();
		WebResponse response = request.GetResponse();
		taskCompletionSource.SetResult(response);
		return taskCompletionSource.Task;
	}

	private static Task<Stream> GetResponseStream(HttpWebRequest webresponse)
	{
		TaskCompletionSource<Stream> taskCompletionSource = new TaskCompletionSource<Stream>();
		Stream result = null;
		try
		{
			result = webresponse.GetRequestStream();
		}
		catch (Exception)
		{
		}
		taskCompletionSource.SetResult(result);
		return taskCompletionSource.Task;
	}

	private static byte[] SetRequestDetails(HttpWebRequest request, int timeOut, string serverBaseUrl, string encodedParams, Encoding encoding)
	{
		byte[] bytes = encoding.GetBytes(encodedParams);
		request.Timeout = timeOut * 1000;
		request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
		request.Referer = serverBaseUrl + "/Login.aspx";
		request.ContentLength = bytes.Length;
		return bytes;
	}
}
