using System;

namespace CommonClientConnector;

public interface IMyICloneable : ICloneable
{
}
