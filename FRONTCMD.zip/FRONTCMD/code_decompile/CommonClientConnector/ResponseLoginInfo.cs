using System;
using System.Net;

namespace CommonClientConnector;

public class ResponseLoginInfo
{
	public Uri Url { get; private set; }

	public string AntiCsrfToken { get; private set; }

	public string ResponseText { get; set; }

	public HttpStatusCode StatusCode { get; set; }

	public ResponseLoginInfo(Uri url, string antiCsrfToken, string responseText)
	{
		Url = url;
		AntiCsrfToken = antiCsrfToken;
		ResponseText = responseText;
	}
}
