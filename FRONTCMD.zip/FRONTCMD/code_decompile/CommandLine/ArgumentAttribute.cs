using System;

namespace CommandLine;

[AttributeUsage(AttributeTargets.Field)]
public class ArgumentAttribute : Attribute
{
	private string shortName;

	private string longName;

	private string helpText;

	private object defaultValue;

	private ArgumentType type;

	private bool allowEmptyValue;

	public ArgumentType Type => type;

	public bool DefaultShortName => shortName == null;

	public string ShortName
	{
		get
		{
			return shortName;
		}
		set
		{
			shortName = value;
		}
	}

	public bool DefaultLongName => longName == null;

	public string LongName
	{
		get
		{
			return longName;
		}
		set
		{
			longName = value;
		}
	}

	public object DefaultValue
	{
		get
		{
			return defaultValue;
		}
		set
		{
			defaultValue = value;
		}
	}

	public bool HasDefaultValue => defaultValue != null;

	public bool HasHelpText => helpText != null;

	public string HelpText
	{
		get
		{
			return helpText;
		}
		set
		{
			helpText = value;
		}
	}

	public bool AllowEmptyValue
	{
		get
		{
			return allowEmptyValue;
		}
		set
		{
			allowEmptyValue = value;
		}
	}

	public ArgumentAttribute(ArgumentType type)
	{
		this.type = type;
		allowEmptyValue = false;
	}
}
