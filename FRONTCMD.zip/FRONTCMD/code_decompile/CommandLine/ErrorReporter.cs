namespace CommandLine;

public delegate void ErrorReporter(string message);
