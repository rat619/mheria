using System;

namespace CommandLine;

[AttributeUsage(AttributeTargets.Field)]
public class DefaultArgumentAttribute : ArgumentAttribute
{
	public DefaultArgumentAttribute(ArgumentType type)
		: base(type)
	{
	}
}
