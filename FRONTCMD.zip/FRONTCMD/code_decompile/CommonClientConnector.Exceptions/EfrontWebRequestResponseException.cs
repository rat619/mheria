using System;

namespace CommonClientConnector.Exceptions;

[Serializable]
public class EfrontWebRequestResponseException : Exception
{
	public EfrontWebRequestResponseException(string message)
		: base(message)
	{
	}
}
