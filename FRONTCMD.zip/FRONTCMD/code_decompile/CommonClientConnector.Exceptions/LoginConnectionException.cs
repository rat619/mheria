using System;

namespace CommonClientConnector.Exceptions;

public class LoginConnectionException : Exception
{
	public LoginConnectionException(string message)
		: base(message)
	{
	}

	public LoginConnectionException(string message, Exception innerException)
		: base(message, innerException)
	{
	}
}
